package com.adobe.assignment.extension.processors;

import java.io.*;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.logging.Logger;

import com.adobe.assignment.extension.MichelSimnakeServer;
import com.adobe.assignment.extension.messages.Request;
import com.adobe.assignment.extension.messages.Response;
import com.adobe.assignment.extension.messages.ResponseStatusCode;
import com.adobe.assignment.extension.messages.header.Headers;
import com.adobe.assignment.extension.services.IContextHandler;
import com.adobe.assignment.extension.utilities.Utils;

/**
 * The {@code HttpProcessor} class encapsulates an http request processor. Process Engine for any incoming client
 * request.
 */
public class HttpProcessor implements IHttpProcessor {

    private static final Logger LOGGER = Logger.getLogger(HttpProcessor.class.getName());

    private final MichelSimnakeServer server;

    /**
     * Constructs a MichelSimnakeServer with the given MichelSimnakeServer.
     * @param server the server
     */
    public HttpProcessor(MichelSimnakeServer server) {
        this.server = server;
    }

    /**
     * Returns the http server.
     * @return the http server
     */
    @Override
    public MichelSimnakeServer getHttpServer() {
        return server;
    }

    /**
     * processes communications for a single connection over the given streams. Multiple subsequent transactions are
     * handled on the connection, until the streams are closed, an error occurs, or the request contains a "Connection:
     * close" header which explicitly requests the connection be closed after the transaction ends.
     * @param requestInputStream the stream from which the incoming requests are read
     * @param requestOutputStream the stream into which the outgoing responses are written
     * @throws IOException if an error occurs
     */
    @Override
    public void processHttpRequest(InputStream requestInputStream, OutputStream requestOutputStream)
            throws IOException {
        requestInputStream = new BufferedInputStream(requestInputStream, 4096);
        requestOutputStream = new BufferedOutputStream(requestOutputStream, 4096);
        Request clientRequest;
        Response serverResponse;
        clientRequest = null;
        serverResponse = new Response(requestOutputStream);
        try {
            clientRequest = new Request(server, requestInputStream);
            processTransaction(clientRequest, serverResponse);
            Utils.transfer(clientRequest.getRequestMessageInputStream(), null, -1);
        } catch (InterruptedIOException interruptedIOException) {
            processException(interruptedIOException, clientRequest, serverResponse, requestOutputStream);
        } catch (IOException | RuntimeException exception) {
            processException(exception, clientRequest, serverResponse, requestOutputStream);
        } finally {
            serverResponse.close();
        }

    }

    private void processException(Throwable throwable, Request clientRequest, Response serverResponse,
            OutputStream requestOutputStream) {
        try {
            if (clientRequest == null) {
                serverResponse.getHeaders()
                        .add("Connection", "close");
                serverResponse.writeError(ResponseStatusCode.STATUS_BAD_REQUEST_400, "Invalid request: "
                        + throwable.getMessage());
            } else if (!serverResponse.isHeadersAlreadyWritten()) {
                serverResponse = new Response(requestOutputStream);
                serverResponse.getHeaders()
                        .add("Connection", "close");
                serverResponse.writeError(ResponseStatusCode.STATUS_INTERNAL_SERVER_ERROR_500,
                        "Error processing request: " + throwable.getMessage());
            }
        } catch (IOException iOException) {
            LOGGER.severe(iOException.getMessage());
        }
    }

    /**
     * processes a single transaction on a connection.
     * <p>
     * Subclasses can override this method to perform filtering on the request or response, apply wrappers to them, or
     * further customize the transaction processing in some other way.
     * @param clientRequest the transaction request
     * @param serverResponse the transaction response (into which the response is written)
     * @throws IOException if and error occurs
     */
    @Override
    public void processTransaction(Request clientRequest, Response serverResponse) throws IOException {
        serverResponse.setClientCapabilities(clientRequest);
        if (preprocessTransaction(clientRequest, serverResponse)) {
            processHttpRequest(clientRequest, serverResponse);
        }
    }

    /**
     * Pre-processes a transaction, performing various validation checks and required special header handling, possibly
     * returning an appropriate response.
     * @param clientRequest the request
     * @param serverResponse the response
     * @return whether further processing should be performed on the transaction
     * @throws IOException if an error occurs
     */
    @Override
    public boolean preprocessTransaction(Request clientRequest, Response serverResponse) throws IOException {
        Headers requestHeaders = clientRequest.getHeaders();
        String version = clientRequest.getVersion();
        serverResponse.setClientCapabilities(clientRequest);
        if (version.equals("HTTP/1.1")) {
            if (!requestHeaders.contains("Host")) {
                serverResponse.writeError(ResponseStatusCode.STATUS_BAD_REQUEST_400, "Missing required Host header");
                return false;
            }
            String expect = requestHeaders.getHeaderValueByName("Expect");
            if (expect != null) {
                if (expect.equalsIgnoreCase("100-continue")) {
                    Response tempResp = new Response(serverResponse.getOutputStream());
                    tempResp.writeHeaders(ResponseStatusCode.STATUS_CONTINUE_100);
                    serverResponse.getOutputStream()
                            .flush();
                } else {
                    serverResponse.writeError(ResponseStatusCode.STATUS_EXPECTATION_FAILED_417);
                    return false;
                }
            }
        } else if (version.equals("HTTP/1.0") || version.equals("HTTP/0.9")) {
            for (String token : Utils.splitElements(requestHeaders.getHeaderValueByName("Connection"), false)) {
                requestHeaders.remove(token);
            }
        } else {
            serverResponse.writeError(ResponseStatusCode.STATUS_BAD_REQUEST_400, "Unknown version: " + version);
            return false;
        }
        return true;
    }

    /**
     * processes a transaction according to the request method.
     * @param clientRequest the transaction request
     * @param serverResponse the transaction response (into which the response is written)
     * @throws IOException if and error occurs
     */
    @Override
    public void processHttpRequest(Request clientRequest, Response serverResponse) throws IOException {
        String method = clientRequest.getMethod();
        Map<String, IContextHandler> handlers = clientRequest.getContextInfo()
                .getHandlers();
        if (method.equals("GET") || handlers.containsKey(method)) {
            deliverContent(clientRequest, serverResponse);
        } else if (method.equals("HEAD")) {
            clientRequest.setMethod("GET");
            serverResponse.setDiscardBody(true);
            deliverContent(clientRequest, serverResponse);
        } else {
            Set<String> methods = new LinkedHashSet<>(Arrays.asList("GET", "HEAD", "OPTIONS"));
            Set<String> firedMethods = handlers.keySet();
            if (clientRequest.getPath()
                    .equals("*")
                    && method.equals("OPTIONS")) {
                firedMethods = clientRequest.getVirtualHost()
                        .getMethods();
            }

            methods.addAll(firedMethods);
            serverResponse.getHeaders()
                    .add("Allow", Utils.joinElements(methods, ", "));
            if (method.equals("OPTIONS")) {
                serverResponse.getHeaders()
                        .add("Content-Length", "0");
                serverResponse.writeHeaders(ResponseStatusCode.STATUS_OK_200);
            } else if (clientRequest.getVirtualHost()
                    .getMethods()
                    .contains(method)) {
                serverResponse.writeHeaders(ResponseStatusCode.STATUS_METHOD_NOT_ALLOWED_405);
            } else {
                serverResponse.writeError(ResponseStatusCode.STATUS_NOT_IMPLEMENTED_501);
            }
        }
    }

    /**
     * Serves the content for a request by invoking the proper service handler for the requested services (path) and
     * HTTP method.
     * @param clientRequest the request
     * @param serverResponse the response into which the content is written
     * @throws IOException if an error occurs
     */
    @Override
    public void deliverContent(Request clientRequest, Response serverResponse) throws IOException {
        IContextHandler handler = clientRequest.getContextInfo()
                .getHandlerByMethod(clientRequest.getMethod());
        if (handler == null) {
            serverResponse.writeError(ResponseStatusCode.STATUS_NOT_FOUND_404);
        } else {
            ResponseStatusCode responseStatus = ResponseStatusCode.STATUS_NOT_FOUND_404;
            String path = clientRequest.getPath();
            if (path.endsWith("/")) {
                String htmlIndexFileName = clientRequest.getVirtualHost()
                        .getHtmlIndexFileName();
                if (htmlIndexFileName != null) {
                    clientRequest.setPath(path + htmlIndexFileName);
                    responseStatus = handler.respond(clientRequest, serverResponse);
                    clientRequest.setPath(path);
                }
            }
            if (responseStatus == ResponseStatusCode.STATUS_NOT_FOUND_404) {
                responseStatus = handler.respond(clientRequest, serverResponse);
            }
            if (responseStatus.getStatusCode() > 0) {
                serverResponse.writeError(responseStatus);
            }
        }

    }

    /**
     * Processes exception a given thrown exception and ultimately updates the server response with the proper error
     * code.
     * @param interruptedIOException the interrupted io exception
     * @param clientRequest the client request
     * @param serverResponse the server response
     * @param requestOutputStream the request output stream
     */
    private void processException(InterruptedIOException interruptedIOException, Request clientRequest,
            Response serverResponse, OutputStream requestOutputStream) {
        try {
            if (clientRequest == null) {
                serverResponse.getHeaders()
                        .add("Connection", "close");
                serverResponse.writeError(ResponseStatusCode.STATUS_REQUEST_TIMEOUT_408,
                        "Timeout waiting for client request");
            } else if (!serverResponse.isHeadersAlreadyWritten()) {
                serverResponse = new Response(requestOutputStream);
                serverResponse.getHeaders()
                        .add("Connection", "close");
                serverResponse.writeError(ResponseStatusCode.STATUS_INTERNAL_SERVER_ERROR_500,
                        "Error processing request: " + interruptedIOException.getMessage());
            }
        } catch (IOException iOException) {
            LOGGER.severe(iOException.getMessage());
        }
    }
}