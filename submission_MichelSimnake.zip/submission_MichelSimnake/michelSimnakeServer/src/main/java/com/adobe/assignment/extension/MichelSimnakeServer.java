package com.adobe.assignment.extension;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Logger;

import javax.net.ServerSocketFactory;

import com.adobe.assignment.extension.hosts.Domain;
import com.adobe.assignment.extension.messages.ResponseStatusCode;
import com.adobe.assignment.extension.processors.HttpProcessor;
import com.adobe.assignment.extension.services.DirectoryFileContentService;
import com.adobe.assignment.extension.services.HealthCheckService;
import com.adobe.assignment.extension.services.IContextHandler;
import com.adobe.assignment.extension.utilities.MichelSimnakeServerCommandLine;
import com.adobe.assignment.extension.utilities.Utils;
import com.adobe.assignment.extension.workers.SocketHandlerThread;

/**
 * The {@code MichelSimnakepServer} class encapsulates the entry point of the Adobe assessment Test HTTP web server.
 * <p>
 * The MichelSimnakepServer implements almost functionality required by RFC 2616 ("Hypertext Transfer Protocol --
 * HTTP/1.1"), as well as some of the optional functionality (this is coined "conditionally compliant" in the RFC) on
 * which this Adobe assessment Test is related. @see : https://greenbytes.de/tech/webdav/rfc2616.html and
 * https://httpd.apache.org/docs/current/vhosts/
 * <p>
 * <b>MichelSimnakepServer: Feature Overview</b>
 * <ul>
 * <li>Directory/File content service (DirectoryFileContentService) - service to serve files and folders from disk</li>
 * <li>Health check service (HealthCheckService) - service used with an external monitoring service or container
 * orchestrator (e.g: Kubernetes) to check the status of MichelSimnakeServer ()</li>
 * <li>Version service - built-in service to get the version of the MichelSimnakeServer</li>
 * <li>Directory index generation - enables browsing folder contents</li>
 * <li>Welcome files - configurable default filename (e.g. index.html)</li>
 * <li>Following HTTP methods are supported - GET/HEAD/OPTIONS</li>
 * <li>Following Conditional statuses are supported - ETags, If-Match , If-None-Match , if-Modified-Since support</li>
 * <li>If-Non-Match This HEADER Handling has been added to meet Adobe requirement (See: Assignment).</li>
 * <li>Allowed Libraries that are used - org.apache.commons and Apache Commons CLI</li>
 * </ul>
 * <b>MichelSimnakepServer: Usages</b>
 * <ul>
 * <li>Directory/File content service : curl -X GET http://localhost:9008/</li>
 * <li>Version service: curl -X GET -H "Content-Type: application/json" http://localhost:9008/api/version/</li>
 * <li>Health check service: curl -X GET -H "Content-Type: application/json" http://localhost:9008/api/healthcheck/</li>
 * </ul>
 */
public class MichelSimnakeServer {

    private static final Logger LOGGER = Logger.getLogger(MichelSimnakeServer.class.getName());

    private final Map<String, Domain> domains = new ConcurrentHashMap<>();
    private volatile int port;

    private volatile ServerSocketFactory serverSocketFactory;
    private volatile ExecutorService serviceExecutor;
    private volatile ServerSocket listener;

    /**
     * Constructs an MichelSimnakepServer which can accept connections on the given port. Note: the {@link #start()}
     * method must be called to start accepting connections.
     * @param port the port on which this server will be listening will accept connections
     */
    private MichelSimnakeServer(int port) {
        setPort(port);
        addVirtualHost(new Domain(null));
    }

    /**
     * Starts a stand-alone server, serving files from disk through .
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            MichelSimnakeServerCommandLine serverOptions = new MichelSimnakeServerCommandLine(args);

            serverOptions.parse();

            File servedDirectory = serverOptions.getDirectory();
            if (!servedDirectory.canRead()) {
                LOGGER.severe("FileNotFoundException: " + servedDirectory.getAbsolutePath());
                throw new FileNotFoundException(servedDirectory.getAbsolutePath());
            }
            LOGGER.info("Targeted Directory: " + servedDirectory.getPath());
            int port = serverOptions.getPort();
            File rootDirectory = new File(servedDirectory, ".mime.types");
            if (rootDirectory.exists()) {
                Utils.addContentTypes(rootDirectory);
            }
            MichelSimnakeServer server = new MichelSimnakeServer(port);
            Domain domain = server.getVirtualHost(null);
            domain.setAllowGeneratedIndex(true);
            domain.addContextInfo("/", new DirectoryFileContentService(server.port, servedDirectory));

            IContextHandler versionContextHandler = (clientRequest, serverResponse) -> {
                serverResponse.getHeaders()
                        .add("Content-Type", "application/json");
                serverResponse.writeResponseMessage(ResponseStatusCode.STATUS_OK_200, String.format(
                        "{\"version\" : \"%s\"}", Utils.VERSION), -1);
                return ResponseStatusCode.STATUS_UNKNOWN_STATUS_0;
            };

            domain.addContextInfo("/api/healthcheck", new HealthCheckService());
            domain.addContextInfo("/api/version", versionContextHandler);
            server.start();
            LOGGER.info("MichelSimnakeServer is listening on port " + port);

        } catch (Exception exception) {
            LOGGER.warning("error: " + exception);
        }
    }

    /**
     * Starts this server. If it is already started, does nothing. Note: Once the server is started,
     * configuration-altering methods of the server and its virtual hosts must not be used.
     * <p>
     * This is not an automated configurable server. To modify the configuration, the server must first be stopped.
     * <p>
     * @throws IOException if the server cannot begin accepting connections
     */
    private synchronized void start() throws IOException {
        if (listener == null) {
            if (serverSocketFactory == null) {
                serverSocketFactory = ServerSocketFactory.getDefault();
            }
            listener = createServerSocket();
            if (serviceExecutor == null) {
                serviceExecutor = Executors.newCachedThreadPool();
            }

            getVirtualHosts().forEach(host -> host.getAliases()
                    .forEach(alias -> domains.put(alias, host)));

            new SocketHandlerThread("socketListenerThread", new HttpProcessor(this)).start();
        }
    }

    /**
     * Returns the port on which this server will accept connections.
     * @return the services port, or null if there is none
     */
    public int getPort() {
        return port;
    }

    /**
     * Sets the port on which this server will accept connections.
     * @param port the port on which this server will accept connections
     */
    private void setPort(int port) {
        this.port = port;
    }

    /**
     * Returns the service executor.
     * @return the executor, or null if there is none
     */
    public Executor getServiceExecutor() {
        return serviceExecutor;
    }

    /**
     * Returns the ServerSocket as listener.
     * @return the listener, or null if there is none
     */
    public ServerSocket getListener() {
        return listener;
    }

    /**
     * Returns the domain or sub-domain with the given name.
     * @param hostName the name of the domain or sub-domain to return, or null for the default domain or sub-domain
     * @return the domain or sub-domain with the given hostName, or null if it doesn't exist
     */
    public Domain getVirtualHost(String hostName) {
        if (hostName == null) {
            return domains.get(Utils.DEFAULT_HOST_NAME);
        }
        return domains.get(hostName);
    }

    /**
     * Returns all domains or sub-domains.
     * @return all domains or sub-domains (as an unmodifiable set)
     */
    private Set<Domain> getVirtualHosts() {
        return Collections.unmodifiableSet(new HashSet<>(domains.values()));
    }

    /**
     * Adds the given domain or sub-domain to the server. If the host's name or aliases already exist, they are
     * overwritten.
     * @param host the domains or sub-domain to add
     */
    private void addVirtualHost(Domain host) {
        String hostName = host.getName();
        if (hostName == null) {
            hostName = Utils.DEFAULT_HOST_NAME;
        }
        domains.put(hostName, host);
    }

    /**
     * Creates the server socket used to accept connections.
     * <p>
     * Cryptic errors seen here often mean the factory configuration details are wrong.
     * @return the created server socket
     * @throws IOException if the socket cannot be created
     */
    private ServerSocket createServerSocket() throws IOException {
        ServerSocket serverSocket = serverSocketFactory.createServerSocket();
        serverSocket.setReuseAddress(true);
        serverSocket.bind(new InetSocketAddress(port));
        return serverSocket;
    }

    /**
     * Stops this server. If it is already stopped, does nothing.
     * <p>
     * Note that if an Executor was set, it must be closed separately.
     */
    public synchronized void stop() {
        try {
            if (listener != null) {
                listener.close();
            }
        } catch (IOException iOException) {
            LOGGER.severe("Stopping the MichelSimnakeServer has failed. " + iOException.getMessage());
        }
        listener = null;
    }
}