package com.adobe.assignment.extension.messages.header;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Logger;

/**
 * The {@code Header} class encapsulates a single HTTP header.
 */
public final class Header {

    private static final Logger LOGGER = Logger.getLogger(Header.class.getName());

    private final String name;
    private final String value;

    /**
     * Constructs a header with the given name and value. Leading and trailing whitespace are trimmed.
     * @param name the header name
     * @param value the header value
     * @throws NullPointerException if name or value is null
     * @throws IllegalArgumentException if name is empty
     */
    Header(String name, String value) throws NullPointerException, IllegalArgumentException {
        this.name = name.trim();
        this.value = value.trim();
        if (this.name.length() == 0) {
            LOGGER.warning("name cannot be empty");
            throw new IllegalArgumentException("name cannot be empty");
        }
    }

    /**
     * Returns the header's name.
     * @return the header's name
     */
    public String getName() {
        return name;
    }

    /**
     * Returns the header's value.
     * @return the header's value
     */
    public String getValue() {
        return value;
    }

    /**
     * The {@code Cookie} class encapsulates a single HTTP Cookie header.
     */
    public static final class Cookie {
        private final String name;
        private final String value;
        private final Date expires;
        private final Integer maxAge;
        private final String domain;
        private final String path;
        private final boolean secure;
        private final String sameSite;
        private boolean httpOnly;

        /**
         * Constructs a Cookie.
         * @param name the name of the cookie
         * @param value the value of the cookie
         * @param expires the expiration date for the cookie
         * @param maxAge the max age of the cookie
         * @param domain the domain of the resource
         * @param path the path of the resource
         * @param secure the secure
         * @param httpOnly the http only
         * @param sameSite the same site
         */
        Cookie(String name, String value, Date expires, Integer maxAge, String domain, String path, boolean secure,
                boolean httpOnly, String sameSite) {
            this.name = name;
            this.value = value;
            this.expires = expires;
            this.maxAge = maxAge;
            this.domain = domain;
            this.path = path;
            this.secure = secure;
            this.httpOnly = httpOnly;
            this.sameSite = sameSite;
        }

        @Override
        public String toString() {
            StringBuilder cookie = new StringBuilder();

            cookie.append(name)
                    .append("=")
                    .append(value);
            if (expires != null) {
                SimpleDateFormat fmt = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss");
                cookie.append("; Expires=")
                        .append(fmt.format(expires))
                        .append(" GMT");
            }
            if (maxAge != null) {
                cookie.append("; Max-Age=")
                        .append(maxAge);
            }
            if (domain != null) {
                cookie.append("; Domain=")
                        .append(domain);
            }
            if (path != null) {
                cookie.append("; Path=")
                        .append(path);
            }
            if (secure) {
                cookie.append("; Secure");
            }
            if (httpOnly) {
                cookie.append("; HttpOnly");
            }
            if (sameSite != null) {
                cookie.append("; SameSite=")
                        .append(sameSite);
            }
            return cookie.toString();
        }
    }

}
