package com.adobe.assignment.extension.services;

import java.io.IOException;
import java.util.Date;

import com.adobe.assignment.extension.hosts.Domain;
import com.adobe.assignment.extension.messages.Request;
import com.adobe.assignment.extension.messages.Response;
import com.adobe.assignment.extension.messages.ResponseStatusCode;
import com.adobe.assignment.extension.messages.header.Headers;
import com.adobe.assignment.extension.utilities.Utils;

/**
 * A {@code ContextHandler} serves the content of resources within a services.
 * @see Domain#addContextInfo
 */
@FunctionalInterface
public interface IContextHandler {

    /**
     * Calculates the appropriate response status code for the given the resource's last-modified time and ETag, based
     * on the conditional headers present in the request.
     * @param clientRequest the request to be served
     * @param resourceLastModifiedTime the resource's last modified time
     * @param entityTag the resource's Entity Tag
     * @return the appropriate response status for the request
     */
    static ResponseStatusCode getConditionalStatus(Request clientRequest, long resourceLastModifiedTime,
            String entityTag) {

        Headers requestHeaders = clientRequest.getHeaders();

        String requestHeader = requestHeaders.getHeaderValueByName("If-Match");
        if (requestHeader != null
                && !Utils.hatEntityTagMatch(!Utils.STRONG_ETAG_MATCH, Utils.splitElements(requestHeader, false),
                        entityTag)) {
            return ResponseStatusCode.STATUS_PRECONDITION_FAILED_412;
        }

        ResponseStatusCode responseStatusCode = ResponseStatusCode.STATUS_OK_200;
        boolean unsatisfiedCondition = false;
        try {
            Date unModifiedSinceDate = requestHeaders.getDate("If-Unmodified-Since");
            if (unModifiedSinceDate != null && resourceLastModifiedTime > unModifiedSinceDate.getTime()) {
                return ResponseStatusCode.STATUS_PRECONDITION_FAILED_412;
            }
            Date modifiedSinceDate = requestHeaders.getDate("If-Modified-Since");
            if (modifiedSinceDate != null && modifiedSinceDate.getTime() <= System.currentTimeMillis()) {
                if (resourceLastModifiedTime > modifiedSinceDate.getTime()) {
                    unsatisfiedCondition = true;
                } else {
                    responseStatusCode = ResponseStatusCode.STATUS_NOT_MODIFIED_304;
                }
            } else if (modifiedSinceDate != null && modifiedSinceDate.getTime() > System.currentTimeMillis()) {
                responseStatusCode = ResponseStatusCode.STATUS_NOT_MODIFIED_304;
            }
        } catch (IllegalArgumentException illegalArgumentException) {
            return ResponseStatusCode.STATUS_BAD_REQUEST_400;
        }

        // This HEADER Handling has been added to meet Adobe requirement (See: Assignment).
        requestHeader = requestHeaders.getHeaderValueByName("If-Non-Match");
        if (requestHeader != null) {
            if (Utils.hatEntityTagMatch(!Utils.STRONG_ETAG_MATCH, Utils.splitElements(requestHeader, false),
                    entityTag)) {
                if (clientRequest.getMethod()
                        .equals("GET")
                        || clientRequest.getMethod()
                                .equals("HEAD")) {
                    responseStatusCode = ResponseStatusCode.STATUS_NOT_MODIFIED_304;
                } else {
                    responseStatusCode = ResponseStatusCode.STATUS_PRECONDITION_FAILED_412;
                }
            } else {
                unsatisfiedCondition = false;
            }
        }
        requestHeader = requestHeaders.getHeaderValueByName("If-None-Match");
        if (requestHeader != null) {
            if (Utils.hatEntityTagMatch(!Utils.STRONG_ETAG_MATCH, Utils.splitElements(requestHeader, false),
                    entityTag)) {
                if (clientRequest.getMethod()
                        .equals("GET")
                        || clientRequest.getMethod()
                                .equals("HEAD")) {
                    responseStatusCode = ResponseStatusCode.STATUS_NOT_MODIFIED_304;
                } else {
                    responseStatusCode = ResponseStatusCode.STATUS_PRECONDITION_FAILED_412;
                }
            } else {
                unsatisfiedCondition = false;
            }
        }

        return unsatisfiedCondition ? ResponseStatusCode.STATUS_OK_200 : responseStatusCode;
    }

    /**
     * Serves the given request using the given response.
     * @param clientRequest the request to be served
     * @param serverResponse the response to be filled
     * @return an HTTP status code, which will be used in returning a default response appropriate for this status. If
     *         this method invocation already sent anything in the response (headers or content), it must return 0, and
     *         no further processing will be done
     * @throws IOException if an IO error occurs
     */
    ResponseStatusCode respond(Request clientRequest, Response serverResponse) throws IOException;
}