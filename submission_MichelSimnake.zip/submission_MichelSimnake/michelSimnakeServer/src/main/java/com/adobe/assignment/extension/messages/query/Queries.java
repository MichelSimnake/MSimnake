package com.adobe.assignment.extension.messages.query;

/**
 * The {@code Queries} class encapsulates a collection of HTTP Request Queries Parameters.
 * <p>
 * Query names are treated case-insensitively, although this class retains their original case. Query insertion order is
 * maintained as well.
 */
public class Queries {

    private Query[] queries = new Query[3];
    private int count;

    /**
     * Adds a query with the given name and value to the end of this collection of queries. Leading and trailing
     * whitespace are trimmed.
     * @param name the query name (case insensitive)
     * @param value the query value
     * @param queryType the query type
     */
    public void add(String name, String value, Query.QueryType queryType) {
        Query query = new Query(name, value, queryType);
        if (count == queries.length) {
            Query[] expanded = new Query[2 * count];
            System.arraycopy(queries, 0, expanded, 0, count);
            queries = expanded;
        }
        queries[count++] = query;
    }

}