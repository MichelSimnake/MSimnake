package com.adobe.assignment.extension.utilities;

import java.io.*;
import java.net.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

import com.adobe.assignment.extension.messages.header.Header;
import com.adobe.assignment.extension.messages.header.Headers;

/**
 * Utility for different, cross-cutting functionality.
 */
public final class Utils {

    public static final String DEFAULT_HOST_NAME = "localhost";
    public static final String VERSION = "1.0-SNAPSHOT";
    public static final int SOCKET_TIMEOUT = 10000;
    public static final boolean STRONG_ETAG_MATCH = true;
    public static final int HEADERS_SIZE = 12;

    /**
     * A convenience array containing the carriage-return and line feed chars.
     */
    public static final byte[] CRLF = { 0x0d, 0x0a };
    private static final int MAX_REQUEST_PARAMS = 8;
    private static final int MAX_HEADERS = 100;
    private static final int UNSIGNED_LONG_RADIX = 10;
    private static final Logger LOGGER = Logger.getLogger(Utils.class.getName());
    /**
     * The SimpleDateFormat-compatible formats of dates which must be supported. Note that all generated date fields
     * must be in the RFC 1123 format only, while the others are supported by recipients for backwards-compatibility.
     */
    private static final String[] DATE_PATTERNS = { "EEE, dd MMM yyyy HH:mm:ss z", "EEEE, dd-MMM-yy HH:mm:ss z",
            "EEE MMM d HH:mm:ss yyyy" };
    /**
     * A GMT (UTC) timezone instance.
     */
    private static final TimeZone GMT = TimeZone.getTimeZone("GMT");
    /**
     * Date format strings.
     */
    private static final char[] DAYS = "Sun Mon Tue Wed Thu Fri Sat".toCharArray(), MONTHS =
            "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".toCharArray();
    /**
     * A mapping of path suffixes (e.g. file extensions) to their corresponding MIME types.
     */
    private static final Map<String, String> contentTypes = new ConcurrentHashMap<>();
    /**
     * The MIME types that can be compressed (prefix/suffix wildcards allowed).
     */
    private static String[] compressibleContentTypes = { "text/*", "*/javascript", "*icon", "*+xml", "*/json" };

    static {
        addContentType("application/font-woff", "woff");
        addContentType("application/font-woff2", "woff2");
        addContentType("application/java-archive", "jar");
        addContentType("application/javascript", "js");
        addContentType("application/json", "json");
        addContentType("application/octet-stream", "exe");
        addContentType("application/pdf", "pdf");
        addContentType("application/x-7z-compressed", "7z");
        addContentType("application/x-compressed", "tgz");
        addContentType("application/x-gzip", "gz");
        addContentType("application/x-tar", "tar");
        addContentType("application/xhtml+xml", "xhtml");
        addContentType("application/zip", "zip");
        addContentType("audio/mpeg", "mp3");
        addContentType("image/gif", "gif");
        addContentType("image/jpeg", "jpg", "jpeg");
        addContentType("image/png", "png");
        addContentType("image/svg+xml", "svg");
        addContentType("image/x-icon", "ico");
        addContentType("text/css", "css");
        addContentType("text/csv", "csv");
        addContentType("text/html; charset=utf-8", "htm", "html");
        addContentType("text/plain", "txt", "text", "log");
        addContentType("text/xml", "xml");
    }

    /**
     * Constructs a Utils as with the given name.
     */
    public Utils() {
        // Utility class
    }

    /**
     * Adds a Content-Type mapping for the given path suffixes. If any of the path suffixes had a previous Content-Type
     * associated with it, it is replaced with the given one. Path suffixes are considered case-insensitive, and
     * contentType is converted to lowercase.
     * @param contentType the content type (MIME type) to be associated with the given path suffixes
     * @param suffixes the path suffixes which will be associated with the contentType, e.g. the file extensions of
     *            served files (excluding the '.' character)
     */
    private static void addContentType(String contentType, String... suffixes) {
        for (String suffix : suffixes) {
            contentTypes.put(suffix.toLowerCase(Locale.US), contentType.toLowerCase(Locale.US));
        }
    }

    /**
     * Adds Content-Type mappings from a standard mime types file.
     * @param mimeFile a mime types file
     * @throws IOException if an error occurs
     * @throws FileNotFoundException if the file is not found or cannot be read
     */
    public static void addContentTypes(File mimeFile) throws IOException, FileNotFoundException {
        try (InputStream inputStream = new FileInputStream(mimeFile)) {
            String line = readLine(inputStream).trim();
            do {
                if (line.length() > 0 && line.charAt(0) != '#') {
                    String[] tokens = splitElements(line, " \t", -1);
                    for (int i = 1; i < tokens.length; i++) {
                        addContentType(tokens[0], tokens[i]);
                    }
                    line = readLine(inputStream).trim();
                }
            } while (line.length() == 0);
        } catch (EOFException eOFException) {
            LOGGER.info(eOFException.getMessage());
        }
    }

    /**
     * Returns the content type for the given path, according to its suffix, or the given default content type if none
     * can be determined.
     * @param path the path whose content type is requested
     * @param def a default content type which is returned if none can be determined
     * @return the content type for the given path, or the given default
     */
    public static String getContentType(String path, String def) {
        int dot = path.lastIndexOf('.');
        String contentType = def;
        if (dot >= 0) {
            contentType = contentTypes.get(path.substring(dot + 1)
                    .toLowerCase(Locale.US));
            if (contentType == null || contentType.isEmpty()) {
                contentType = def;
            }
        }
        return contentType;
    }

    /**
     * Checks whether data of the given content type (MIME type) is compressible.
     * @param contentType the content type
     * @return true if the data is compressible, false if not
     */
    public static boolean isCompressible(String contentType) {
        int pos = contentType.indexOf(';');
        String type = pos < 0 ? contentType : contentType.substring(0, pos);

        return Arrays.stream(compressibleContentTypes)
                .anyMatch(compressibleContentType -> compressibleContentType.equals(type)
                        || compressibleContentType.charAt(0) == '*'
                                && type.endsWith(compressibleContentType.substring(1))
                        || compressibleContentType.charAt(compressibleContentType.length() - 1) == '*'
                                && type.startsWith(compressibleContentType.substring(0, compressibleContentType.length()
                                        - 1)));
    }

    /**
     * Returns the local host's auto-detected name.
     * @return the local host name
     */
    public static String detectLocalHostName() {
        try {
            return InetAddress.getLocalHost()
                    .getCanonicalHostName();
        } catch (UnknownHostException unknownHostException) {
            return "localhost";
        }
    }

    /**
     * Parses name-value pair parameters from the given "x-www-form-urlencoded" MIME-type string. This is the encoding
     * used both for parameters passed as the query of an HTTP GET method, and as the content of HTML forms submitted
     * using the HTTP POST method (as long as they use the default "application/x-www-form-urlencoded" encoding in their
     * ENCTYPE attribute). UTF-8 encoding is assumed.
     * <p>
     * The parameters are returned as a list of string arrays, each containing the parameter name as the first element
     * and its corresponding value as the second element (or an empty string if there is no value).
     * <p>
     * The list retains the original order of the parameters.
     * @param requestParams an "application/x-www-form-urlencoded" string
     * @return the parameter name-value pairs parsed from the given string, or an empty list if there are none
     */
    public static List<String[]> parseParamsList(String requestParams) {
        if (requestParams == null || requestParams.length() == 0) {
            return Collections.emptyList();
        }
        List<String[]> params = new ArrayList<>(MAX_REQUEST_PARAMS);

        for (String keyValue : splitElements(requestParams, "&", -1)) {
            int pos = keyValue.indexOf('=');
            String paramName = pos < 0 ? keyValue : keyValue.substring(0, pos);
            String paramValue = pos < 0 ? "" : keyValue.substring(pos + 1);
            try {
                paramName = URLDecoder.decode(paramName.trim(), "UTF-8");
                paramValue = URLDecoder.decode(paramValue.trim(), "UTF-8");
                if (paramName.length() > 0) {
                    params.add(new String[] { paramName, paramValue });
                }
            } catch (UnsupportedEncodingException unsupportedEncodingException) {
                LOGGER.info(unsupportedEncodingException.getMessage());
            }
        }
        return params;
    }

    /**
     * Converts a collection of pairs of objects (arrays of size two, each representing a key and corresponding value)
     * into a Map. Duplicate keys are ignored (only the first occurrence of each key is considered). The map retains the
     * original collection's iteration order.
     * @param keyValues a collection of arrays, each containing a key and corresponding value
     * @param <K> the key type
     * @param <V> the value type
     * @return a map containing the paired keys and values, or an empty map
     */
    public static <K, V> Map<K, V> toMap(Collection<? extends Object[]> keyValues) {
        if (keyValues == null || keyValues.isEmpty()) {
            return Collections.emptyMap();
        }
        Map<K, V> map = new LinkedHashMap<>(keyValues.size());
        keyValues.forEach(p -> {
            Object[] keyValue = p;
            if (!map.containsKey(keyValue[0])) {
                map.put((K) keyValue[0], (V) keyValue[1]);
            }
        });

        return map;
    }

    /**
     * Returns the absolute (zero-based) content range value specified by the given range string. If multiple ranges are
     * requested, a single range containing all of them is returned.
     * @param range the string containing the range description
     * @param length the full length of the requested resource
     * @return the requested range, or null if the range value is invalid
     */
    public static long[] parseRange(String range, long length) {
        long min = Long.MAX_VALUE;
        long max = Long.MIN_VALUE;
        try {
            for (String token : splitElements(range, false)) {
                long start, end;
                int dash = token.indexOf('-');
                if (dash == 0) {
                    start = length - parseULong(token.substring(1), UNSIGNED_LONG_RADIX);
                    end = length - 1;
                } else if (dash == token.length() - 1) {
                    start = parseULong(token.substring(0, dash), UNSIGNED_LONG_RADIX);
                    end = length - 1;
                } else {
                    start = parseULong(token.substring(0, dash), UNSIGNED_LONG_RADIX);
                    end = parseULong(token.substring(dash + 1), UNSIGNED_LONG_RADIX);
                }
                if (end < start) {
                    LOGGER.warning("Parsing has Failed with end < start");
                    throw new RuntimeException();
                }
                if (start < min) {
                    min = start;
                }
                if (end > max) {
                    max = end;
                }
            }
            if (max < 0) {
                LOGGER.warning("Parsing has Failed with max < 0");
                throw new RuntimeException();
            }
            if (max >= length && min < length) {
                max = length - 1;
            }
            return new long[] { min, max };
        } catch (RuntimeException runtimeException) {
            LOGGER.warning(runtimeException.getMessage());
            return null;
        }
    }

    /**
     * Parses an unsigned long value. This method behaves the same as calling {@link Long#parseLong(String, int)}, but
     * considers the string invalid if it starts with an ASCII minus sign ('-') or plus sign ('+').
     * @param uLongString the String containing the long representation to be parsed
     * @param radix the radix to be used while parsing s
     * @return the long represented by s in the specified radix
     * @throws NumberFormatException if the string does not contain a parsable long, or if it starts with an ASCII minus
     *             sign or plus sign
     */
    public static long parseULong(String uLongString, int radix) throws NumberFormatException {
        long val = Long.parseLong(uLongString, radix);
        if (uLongString.charAt(0) == '-' || uLongString.charAt(0) == '+') {
            LOGGER.warning("invalid digit: " + uLongString.charAt(0));
            throw new NumberFormatException("invalid digit: " + uLongString.charAt(0));
        }
        return val;
    }

    /**
     * Parses a date string in one of the supported {@link #DATE_PATTERNS}.
     * <p>
     * Received date header values must be in one of the following formats: Sun, 06 Nov 1994 08:49:37 GMT ; RFC 822,
     * updated by RFC 1123 Sunday, 06-Nov-94 08:49:37 GMT ; RFC 850, obsoleted by RFC 1036 Sun Nov 6 08:49:37 1994 ;
     * ANSI C's asctime() format
     * @param time a string representation of a time value
     * @return the parsed date value
     * @throws IllegalArgumentException if the given string does not contain a valid date format in any of the supported
     *             formats
     */
    public static Date parseDate(String time) throws IllegalArgumentException {
        for (String pattern : DATE_PATTERNS) {
            try {
                SimpleDateFormat df = new SimpleDateFormat(pattern, Locale.US);
                df.setLenient(false);
                df.setTimeZone(GMT);
                return df.parse(time);
            } catch (ParseException parseException) {
                LOGGER.warning(parseException.getMessage());
            }
        }
        LOGGER.warning("invalid date format: " + time);
        throw new IllegalArgumentException("invalid date format: " + time);
    }

    /**
     * Formats the given time value as a string in RFC 1123 format. Copied from:
     * https://www.programcreek.com/java-api-examples/?code=Betalord/BHBot/BHBot-master/src/HTTPServer.java and refined
     * @param time the time in milliseconds since January 1, 1970, 00:00:00 GMT
     * @return the given time value as a string in RFC 1123 format
     */
    public static String formatDate(long time) {
        if (time < -62167392000000L || time > 253402300799999L) {
            LOGGER.warning("year out of range (0001-9999): " + time);
            throw new IllegalArgumentException("year out of range (0001-9999): " + time);
        }
        char[] s = "DAY, 00 MON 0000 00:00:00 GMT".toCharArray();
        Calendar cal = new GregorianCalendar(GMT, Locale.US);
        cal.setTimeInMillis(time);
        System.arraycopy(DAYS, 4 * (cal.get(Calendar.DAY_OF_WEEK) - 1), s, 0, 3);
        System.arraycopy(MONTHS, 4 * cal.get(Calendar.MONTH), s, 8, 3);
        int n = cal.get(Calendar.DATE);
        s[5] += n / 10;
        s[6] += n % 10;
        n = cal.get(Calendar.YEAR);
        s[12] += n / 1000;
        s[13] += n / 100 % 10;
        s[14] += n / 10 % 10;
        s[15] += n % 10;
        n = cal.get(Calendar.HOUR_OF_DAY);
        s[17] += n / 10;
        s[18] += n % 10;
        n = cal.get(Calendar.MINUTE);
        s[20] += n / 10;
        s[21] += n % 10;
        n = cal.get(Calendar.SECOND);
        s[23] += n / 10;
        s[24] += n % 10;
        return new String(s);
    }

    /**
     * Add one day date to the a given date.
     * @param date the date
     * @return the date
     * @throws NullPointerException the null pointer exception
     */
    public static Date addOneDay(Date date) throws NullPointerException {
        Objects.requireNonNull(date, "Given date should not be null!\"");
        LocalDateTime localDateTime = date.toInstant()
                .atZone(ZoneId.systemDefault())
                .toLocalDateTime();
        localDateTime = localDateTime.plusDays(1);
        return Date.from(localDateTime.atZone(ZoneId.systemDefault())
                .toInstant());
    }

    /**
     * Splits the given element list string (comma-separated header value) into its constituent non-empty trimmed
     * elements. (RFC2616#2.1: element lists are delimited by a comma and optional LWS, and empty elements are ignored).
     * @param elements the element list string
     * @param lower specifies whether the list elements should be lower-cased
     * @return the non-empty elements in the list, or an empty array
     */
    public static String[] splitElements(String elements, boolean lower) {
        String elementsList = elements;
        if (lower && elements != null) {
            elementsList = elements.toLowerCase(Locale.US);
        }
        return splitElements(elementsList, ",", -1);
    }

    /**
     * Splits the given element list string (comma-separated header value) into its constituent non-empty trimmed
     * elements. (RFC2616#2.1: element lists are delimited by a comma and optional LWS, and empty elements are ignored).
     * @param elements the element list string
     * @param lower specifies whether the list elements should be lower-cased
     * @return the non-empty elements in the list, or an empty List
     */
    public static List<String> splitElementsToList(String elements, boolean lower) {
        String elementsList = elements;
        if (lower && elements != null) {
            elementsList = elements.toLowerCase(Locale.US);
        }

        String[] splitElements = splitElements(elementsList, ",", -1);
        if (ArrayUtils.isNotEmpty(splitElements)) {
            return Arrays.asList(splitElements);
        } else {
            return new ArrayList<>();
        }
    }

    /**
     * Splits the given string into its constituent non-empty trimmed elements, which are delimited by any of the given
     * separator characters. This is a more direct and efficient implementation than using a regex (e.g.
     * String.split()), trimming the elements and removing empty ones.
     * @param elements the string to split
     * @param separator the characters used as the separator between elements
     * @param limit if positive, limits the returned array size (remaining of str in last element)
     * @return the non-empty elements in the string, or an empty array
     */
    public static String[] splitElements(String elements, String separator, int limit) {
        return StringUtils.split(elements, separator, limit);
    }

    /**
     * Returns a string constructed by joining the string representations of the iterated objects (in order), with the
     * separator inserted between them.
     * @param separator the separator that is inserted between the joined strings
     * @param items the items whose string representations are joined
     * @param <T> the item type
     * @return the joined string
     */
    public static <T> String joinElements(Iterable<T> items, String separator) {
        return StringUtils.join(items, separator);
    }

    /**
     * Returns the parent of the given path.
     * @param path the path whose parent is returned (must start with '/')
     * @return the parent of the given path (excluding trailing slash), or null if given path is the root path
     */
    public static String getParentPath(String path) {
        path = trimRightCharacters(path, "/");
        int slash = path.lastIndexOf('/');
        return slash < 0 ? null : path.substring(0, slash);
    }

    /**
     * Returns the given string without all occurrences of any character of the given string removed from its right
     * side.
     * @param elementToTrim the string to trim
     * @param stringToRemove the string to remove
     * @return the trimmed string
     */
    public static String trimRightCharacters(String elementToTrim, String stringToRemove) {
        return StringUtils.stripEnd(elementToTrim, stringToRemove);
    }

    /**
     * Trims duplicate consecutive occurrences of the given character within the given string, replacing them with a
     * single instance of the character.
     * @param elementToTrim the string to trim
     * @param targetCharacter the target character
     * @return the given string with duplicate consecutive occurrences of c replaced by a single instance of c
     */
    public static String trimDuplicatesCharacter(String elementToTrim, char targetCharacter) {
        int start = 0;
        while ((start = elementToTrim.indexOf(targetCharacter, start) + 1) > 0) {
            int end;
            for (end = start; end < elementToTrim.length() && elementToTrim.charAt(end) == targetCharacter; end++)
                ;
            if (end > start) {
                elementToTrim = elementToTrim.substring(0, start) + elementToTrim.substring(end);
            }
        }
        return elementToTrim;
    }

    /**
     * Returns a human-friendly string approximating the given data size, e.g. "316 byte", "1.8 KB", "324 MB", "324
     * GB","324 TB","324 PB","324 EB", "324 YB", etc.
     * @param bytesSize the size in byte to display
     * @return a human-friendly string approximating the given data size
     */
    private static String formatFileSize(double bytesSize) {
        String[] dictionary = { "bytes", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB" };
        int index;
        for (index = 0; index < dictionary.length; index++) {
            if (bytesSize < 1024) {
                break;
            }
            bytesSize = bytesSize / 1024;
        }
        return String.format("  %." + 2 + "f", bytesSize) + " " + dictionary[index];
    }

    /**
     * Returns an HTML-escaped version of the given string for safe display within a web page. The characters '&amp;',
     * '&gt;' and '&lt;' must always be escaped, and single and double quotes must be escaped within attribute values;
     * this method escapes them always. This method can be used for generating both HTML and XHTML valid content. Copied
     * from https://www.programcreek.com/java-api-examples/?code=Betalord/BHBot/BHBot-master/src/HTTPServer.java and
     * refined.
     * @param elementToEscape the string to escape
     * @return the escaped HTML string
     * @see <a href="http://www.w3.org/International/questions/qa-escapes">The W3C FAQ</a>
     */
    public static String escapeHTML(String elementToEscape) {
        int length = elementToEscape.length();
        StringBuilder htmlStringBuilder = new StringBuilder(length + 30);
        int start = 0;
        for (int i = 0; i < length; i++) {
            String ref = null;
            switch (elementToEscape.charAt(i)) {
            case '&':
                ref = "&amp;";
                break;
            case '>':
                ref = "&gt;";
                break;
            case '<':
                ref = "&lt;";
                break;
            case '"':
                ref = "&quot;";
                break;
            case '\'':
                ref = "&#39;";
                break;
            }

            if (ref != null) {
                htmlStringBuilder.append(elementToEscape, start, i)
                        .append(ref);
                start = i + 1;
            }
        }
        return start == 0 ? elementToEscape : htmlStringBuilder.append(elementToEscape.substring(start))
                .toString();
    }

    /**
     * Converts strings to bytes by casting the chars to bytes. This is a fast way to encode a string as
     * ISO-8859-1/US-ASCII bytes. If multiple strings are provided, their bytes are concatenated.
     * @param messages the strings to convert (containing only ISO-8859-1 chars)
     * @return the byte array
     */
    public static byte[] getBytes(String... messages) {
        int size = 0;
        for (String message : messages) {
            size += message.length();
        }
        byte[] concatenatedByteMessages = new byte[size];
        size = 0;
        for (String message : messages) {
            int index = 0;
            int length = message.length();
            for (; index < length; index++) {
                concatenatedByteMessages[size++] = (byte) message.charAt(index);
            }
        }
        return concatenatedByteMessages;
    }

    /**
     * Transfers data from an input stream to an output stream.
     * @param sourceStream the input stream to transfer from
     * @param destinationStream the output stream to transfer to (or null to discard output)
     * @param length the number of bytes to transfer. If negative, the entire contents of the input stream are
     *            transferred.
     * @throws IOException if an IO error occurs or the input stream ends before the requested number of bytes have been
     *             read
     */
    public static void transfer(InputStream sourceStream, OutputStream destinationStream, long length)
            throws IOException {
        if (length == 0 || destinationStream == null && length < 0 && sourceStream.read() < 0) {
            return; // small optimization - avoid buffer creation
        }
        byte[] buffer = new byte[4096];
        while (length != 0) {
            int size = (length < 0 || buffer.length < length) ? buffer.length : (int) length;
            size = sourceStream.read(buffer, 0, size);
            if (size < 0) {
                if (length > 0) {
                    LOGGER.warning("unexpected end of stream.");
                    throw new IOException("unexpected end of stream.");
                }
                break;
            }
            if (destinationStream != null) {
                destinationStream.write(buffer, 0, size);
            }
            length -= length > 0 ? size : 0;
        }
    }

    /**
     * Reads the token starting at the current stream position and ending at the first occurrence of the given delimiter
     * byte, in the given encoding.
     * @param tokenInputStream the stream from which the token is read
     * @param delimiter the byte value which marks the end of the token, or -1 if the token ends at the end of the
     *            stream
     * @param encoding a character-encoding name
     * @param maxLength the maximum length (in bytes) to read
     * @return the read token, excluding the delimiter
     * @throws UnsupportedEncodingException if the encoding is not supported
     * @throws EOFException if the stream end is reached before a delimiter is found
     * @throws IOException if an IO error occurs, or the maximum length is reached before the token end is reached
     * @throws NullPointerException if the given stream is null
     */
    public static String readToken(InputStream tokenInputStream, int delimiter, String encoding, int maxLength)
            throws IOException, UnsupportedEncodingException, NullPointerException {
        Objects.requireNonNull(tokenInputStream, "tokenInputStream should not be null!\"");
        int bufferLength = Math.min(maxLength, 512);
        byte[] buffer = new byte[bufferLength];
        int count = 0;
        int data = tokenInputStream.read();
        while (data != -1 && data != delimiter) {
            if (count == bufferLength) {
                if (count == maxLength) {
                    LOGGER.warning("token too large (" + count + ").");
                    throw new IOException("token too large (" + count + ").");
                }
                bufferLength = Math.min(maxLength, 2 * bufferLength);
                byte[] expanded = new byte[bufferLength];
                System.arraycopy(buffer, 0, expanded, 0, count);
                buffer = expanded;
            }
            buffer[count++] = (byte) data;
            data = tokenInputStream.read();
        }
        if (data < 0 && delimiter != -1) {
            LOGGER.warning("Unexpected end of stream.");
            throw new EOFException("Unexpected end of stream.");
        }
        return new String(buffer, 0, count, encoding);
    }

    /**
     * Reads the ISO-8859-1 encoded string starting at the current stream position and ending at the first occurrence of
     * the LF character.
     * @param lineInputStream the stream from which the line is read
     * @return the read string, excluding the terminating LF character and (if exists) the CR character immediately
     *         preceding it
     * @throws EOFException if the stream end is reached before an LF character is found
     * @throws IOException if an IO error occurs, or the line is longer than 8192 bytes
     * @throws NullPointerException if the given stream is null
     * @see #readToken(InputStream, int, String, int)
     */
    public static String readLine(InputStream lineInputStream) throws IOException, EOFException {
        Objects.requireNonNull(lineInputStream, "lineInputStream should not be null!\"");
        String line = readToken(lineInputStream, '\n', "ISO8859_1", 8192);

        if (line.length() > 0 && line.charAt(line.length() - 1) == '\r') {
            line = line.substring(0, line.length() - 1);
        }

        return line;
    }

    /**
     * Reads headers from the given stream. Headers are read according to the RFC, including folded headers, element
     * lists, and multiple headers (which are concatenated into a single element list header). Leading and trailing
     * whitespace is removed.
     * @param headersInputStream the stream from which the headers are read
     * @return the read headers (possibly empty, if none exist)
     * @throws IOException if an IO error occurs or the headers are malformed or there are more than 100 header lines
     * @throws NullPointerException if the given stream is null
     */
    public static Headers readHeaders(InputStream headersInputStream) throws IOException {
        Objects.requireNonNull(headersInputStream, "headersInputStream should not be null!\"");
        Headers headers = new Headers();
        String line = readLine(headersInputStream);
        String prevLine = "";
        int count = 0;
        while (line.length() > 0) {
            int first;
            for (first = 0; first < line.length() && Character.isWhitespace(line.charAt(first)); first++)
                ;
            if (first > 0) {
                line = prevLine + ' ' + line.substring(first);
            }
            int separator = line.indexOf(':');
            if (separator < 0) {
                LOGGER.warning("invalid header: \"" + line + "\".");
                throw new IOException("invalid header: \"" + line + "\".");
            }
            String name = line.substring(0, separator);
            String value = line.substring(separator + 1)
                    .trim();
            Header replaced = headers.replace(name, value);
            if (replaced != null && first == 0) {
                value = replaced.getValue() + ", " + value;
                line = name + ": " + value;
                headers.replace(name, value);
            }
            prevLine = line;
            line = readLine(headersInputStream);
            if (++count > MAX_HEADERS) {
                LOGGER.warning("too many header lines.");
                throw new IOException("too many header lines.");
            }
        }
        return headers;
    }

    /**
     * Compares the given entityTag value against the given entityTags. A match is found if the given entityTag is not
     * null, and either the entityTag contain a "*" value, or one of them is identical to the given entityTag. If strong
     * comparison is used, tags beginning with the weak ETag prefix "W/" never match. See RFC2616#3.11, RFC2616#13.3.3.
     * @param strong if true, strong comparison is used, otherwise weak comparison is used
     * @param entityTags the entityTags to match against
     * @param entityTag the entityTag to match
     * @return true if the entityTag is matched, false otherwise
     */
    public static boolean hatEntityTagMatch(boolean strong, String[] entityTags, String entityTag) {
        if (entityTag == null || strong && entityTag.startsWith("W/")) {
            return false;
        }

        return Arrays.stream(entityTags)
                .anyMatch(e -> e.equals("*") || (e.equals(entityTag) && !(strong && (e.startsWith("W/")))));
    }

    /**
     * Serves the contents of a directory as an HTML file index.
     * @param directory the existing and readable directory whose contents are served
     * @param path the displayed base path corresponding to dir
     * @return an HTML string containing the file index for the directory
     * @throws NullPointerException if {@link File#list()} is {@code null}
     */
    public static String createHtmlDirectoryContent(File directory, String path) throws NullPointerException {
        if (!path.endsWith("/")) {
            path += "/";
        }
        int width = 21;
        for (String name : Objects.requireNonNull(directory.list())) {
            if (name.length() > width) {
                width = name.length();
            }
        }

        width += 2;
        Formatter formatter = new Formatter(Locale.US);
        formatter.format("<!DOCTYPE html>%n"
                + "<html><head><title>Index of %s</title></head>%n"
                + "<body><h1>Index of %s</h1>%n"
                + "<pre> Name%"
                + (width - 5)
                + "s Last modified      Size<hr>", path, path, "");
        if (path.length() > 1) {
            formatter.format(" <a href=\"%s/\">Parent Directory</a>%" + (width + 5) + "s-%n", getParentPath(path), "");
        }
        for (File file : Objects.requireNonNull(directory.listFiles())) {
            try {
                String name = file.getName() + (file.isDirectory() ? "/" : "");
                String size = file.isDirectory() ? "- " : formatFileSize(file.length());
                String link = new URI(null, path + name, null).toASCIIString();
                if (!file.isHidden() && !name.startsWith(".")) {
                    formatter.format(" <a href=\"%s\">%s</a>%-"
                            + (width - name.length())
                            + "s&#8206;%td-%<tb-%<tY %<tR%6s%n", link, name, "", file.lastModified(), size);
                }
            } catch (URISyntaxException uRISyntaxException) {
                LOGGER.warning(uRISyntaxException.getMessage());
            }
        }
        formatter.format("</pre></body></html>");
        return formatter.toString();
    }
}
