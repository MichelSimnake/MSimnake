package com.adobe.assignment.extension.messages;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.logging.Logger;

import com.adobe.assignment.extension.MichelSimnakeServer;
import com.adobe.assignment.extension.hosts.Domain;
import com.adobe.assignment.extension.messages.header.Headers;
import com.adobe.assignment.extension.messages.query.Queries;
import com.adobe.assignment.extension.messages.query.Query;
import com.adobe.assignment.extension.services.context.ContextInfo;
import com.adobe.assignment.extension.streams.ChunkedInputStream;
import com.adobe.assignment.extension.streams.LimitedInputStream;
import com.adobe.assignment.extension.utilities.Utils;

/**
 * The {@code Request} class encapsulates a single HTTP request.
 */
public class Request implements Closeable {

    private static final Logger LOGGER = Logger.getLogger(Request.class.getName());

    private final MichelSimnakeServer server;
    private String method;
    private URI requestUri;
    private Queries queries;
    private URL baseURL;
    private String version;
    private Headers headers;
    private InputStream requestMessageInputStream;
    private Domain currentDomain;
    private ContextInfo contextInfo;

    /**
     * Constructs a Request from the data in the given input stream.
     * @param server the server
     * @param requestInputStream the input stream from which the request is read
     * @throws IOException if an error occurs
     */
    public Request(MichelSimnakeServer server, InputStream requestInputStream) throws IOException,
            NullPointerException {
        readRequestStartLine(requestInputStream);
        readRequestHeaders(requestInputStream);
        readRequestQueries();
        this.server = server;
        String header = headers.getHeaderValueByName("Transfer-Encoding");
        if (header != null
                && !header.toLowerCase(Locale.US)
                        .equals("identity")) {
            if (Utils.splitElementsToList(header, true)
                    .contains("chunked")) {
                requestMessageInputStream = new ChunkedInputStream(requestInputStream, headers);
            } else {
                requestMessageInputStream = requestInputStream;
            }
        } else {
            header = headers.getHeaderValueByName("Content-Length");
            long length = header == null ? 0 : Utils.parseULong(header, 10);
            requestMessageInputStream = new LimitedInputStream(requestInputStream, length, false);
        }
    }

    /**
     * Returns the request method.
     * @return the request method
     */
    public String getMethod() {
        return method;
    }

    /**
     * Sets method.
     * @param method the method
     */
    public void setMethod(String method) {
        this.method = method;
    }

    /**
     * Returns the request version string.
     * @return the request version string
     */
    public String getVersion() {
        return version;
    }

    /**
     * Returns the request headers.
     * @return the request headers
     */
    public Headers getHeaders() {
        return headers;
    }

    /**
     * Returns the input stream containing the request messages.
     * @return the input stream containing the request messages
     */
    public InputStream getRequestMessageInputStream() {
        return requestMessageInputStream;
    }

    /**
     * Returns the path component of the request URI, after URL decoding has been applied (using the UTF-8 charset).
     * @return the decoded path component of the request URI
     */
    public String getPath() {
        return requestUri.getPath();
    }

    /**
     * Sets the path component of the request URI. This can be useful in URL rewriting, etc.
     * @param path the path to set
     * @throws IllegalArgumentException if the given path is malformed
     */
    public void setPath(String path) {
        try {
            requestUri = new URI(requestUri.getScheme(), requestUri.getHost(), Utils.trimDuplicatesCharacter(path, '/'),
                    requestUri.getFragment());
            contextInfo = null;
        } catch (URISyntaxException uRISyntaxException) {
            LOGGER.warning("error setting path" + uRISyntaxException.getMessage());
            throw new IllegalArgumentException("error setting path", uRISyntaxException);
        }
    }

    /**
     * Returns the base URL (scheme, host and port) of the request resource. The host name is taken from the request URI
     * or the Host header or a default host (see RFC2616#5.2).
     * @param port the port of the connection
     * @return the base URL of the requested resource, or null if it is malformed
     */
    public URL getBaseURL(int port) {
        if (baseURL != null) {
            return baseURL;
        }
        String host = requestUri.getHost();
        if (host == null) {
            host = headers.getHeaderValueByName("Host");
            if (host == null) {
                host = Utils.detectLocalHostName();
            }
        }
        int pos = host.indexOf(':');
        host = pos < 0 ? host : host.substring(0, pos);
        try {
            return baseURL = new URL("http", host, port, "");
        } catch (MalformedURLException malformedURLException) {
            LOGGER.severe(malformedURLException.getMessage());
            return null;
        }
    }

    /**
     * Reads the request optional headers, parsing the Headers lines as well as the messages body.
     * @param requestInputStream the input stream from which the request headers are read
     * @throws IOException if an error occurs or the request line is invalid
     * @throws NullPointerException if the given stream is null
     */
    private void readRequestHeaders(InputStream requestInputStream) throws IOException, NullPointerException {
        Objects.requireNonNull(requestInputStream, "requestInputStream should not be null!");
        headers = Utils.readHeaders(requestInputStream);
    }

    /**
     * Returns the request parameters, which are parsed both from the query part of the request URI, and from the
     * request body if its content type is "application/x-www-form-urlencoded" (i.e. a submitted form). UTF-8 encoding
     * is assumed in both cases.
     * <p>
     * The parameters are returned as a list of Query, each containing the parameter name and its corresponding value
     * (or an empty string if there is no value) as well as the category of the query (Request Param or Message body
     * param).
     * <p>
     * The list retains the original order of the parameters.
     * @return the request parameters name-value pairs, or an empty list if there are none
     * @throws IOException if an error occurs
     * @see Utils#parseParamsList(String)
     */
    private List<Query> getQueriesList() throws IOException {
        List<Query> requestUriQueries = new ArrayList<>();
        List<Query> requestBodyQueries = new ArrayList<>();
        List<String[]> queryParams = Utils.parseParamsList(requestUri.getRawQuery());
        Utils.toMap(queryParams)
                .forEach((name, value) -> requestUriQueries.add(new Query((String) name, (String) value,
                        Query.QueryType.URI)));
        List<String[]> bodyParams;
        String requestContentType = headers.getHeaderValueByName("Content-Type");
        if (requestContentType != null
                && requestContentType.toLowerCase(Locale.US)
                        .startsWith("application/x-www-form-urlencoded")) {
            bodyParams = Utils.parseParamsList(Utils.readToken(requestMessageInputStream, -1, "UTF-8", 2097152));
            Utils.toMap(bodyParams)
                    .forEach((name, value) -> requestBodyQueries.add(new Query((String) name, (String) value,
                            Query.QueryType.BODY)));
        }
        if (requestBodyQueries.isEmpty()) {
            return requestUriQueries;
        }
        if (requestUriQueries.isEmpty()) {
            return requestBodyQueries;
        }
        requestUriQueries.addAll(requestBodyQueries);
        return requestUriQueries;
    }

    /**
     * Sets the request query parameters, which are parsed both from the query part of the request URI, and from the
     * request body if its content type is "application/x-www-form-urlencoded" (i.e. a submitted form). UTF-8 encoding
     * is assumed in both cases.
     * <p>
     * For multivalued parameters (i.e. multiple parameters with the same name), only the first one is considered. For
     * access to all values, use {@link #getQueriesList()} instead.
     * <p>
     * The map iteration retains the original order of the parameters.
     * @throws IOException if an error occurs
     * @see #getQueriesList()
     */
    private void readRequestQueries() throws IOException {
        if (queries == null) {
            queries = new Queries();
            getQueriesList().forEach(query -> queries.add(query.getName(), query.getValue(), query.getQueryType()));
        }
    }

    /**
     * Returns the absolute (zero-based) content range value read from the Range header. If multiple ranges are
     * requested, a single range containing all of them is returned.
     * @param length the full length of the requested resource
     * @return the requested range, or null if the Range header is missing or invalid
     */
    public long[] getRange(long length) {
        String header = headers.getHeaderValueByName("Range");
        return header == null || !header.startsWith("bytes=") ? null : Utils.parseRange(header.substring(6), length);
    }

    /**
     * Reads the request start line, parsing the method, URI and version string.
     * @param requestInputStream the input stream from which the request line is read
     * @throws IOException if an error occurs or the request line is invalid
     * @throws NullPointerException if the given stream is null
     */
    private void readRequestStartLine(InputStream requestInputStream) throws IOException, NullPointerException {
        Objects.requireNonNull(requestInputStream, "requestInputStream should not be null!");
        String requestStartLine;
        try {
            do {
                requestStartLine = Utils.readLine(requestInputStream);
            } while (requestStartLine.length() == 0);
        } catch (IOException iOException) {
            LOGGER.warning("missing request line. " + iOException.getMessage());
            throw new IOException("missing request line.");
        }
        String[] tokens = Utils.splitElements(requestStartLine, " ", -1);
        if (tokens.length != 3) {
            LOGGER.warning("invalid request line: \"" + requestStartLine + "\".");
            throw new IOException("invalid request line: \"" + requestStartLine + "\".");
        }
        try {
            method = tokens[0];
            requestUri = new URI(Utils.trimDuplicatesCharacter(tokens[1], '/'));
            version = tokens[2];
        } catch (URISyntaxException uRISyntaxException) {
            LOGGER.warning("invalid URI: " + uRISyntaxException.getMessage() + ".");
            throw new IOException("invalid URI: " + uRISyntaxException.getMessage() + ".");
        }
    }

    /**
     * Returns the domain or sub-domain corresponding to the requested host name, or the default host if none exists.
     * @return the domain or sub-domain corresponding to the requested host name, or the default virtual host
     */
    public Domain getVirtualHost() {
        if (currentDomain == null) {
            URL baseUrl = getBaseURL(server.getPort());
            currentDomain = server.getVirtualHost(baseUrl.getHost());
            if (currentDomain == null) {
                currentDomain = server.getVirtualHost(null);
            }
        }
        return currentDomain;
    }

    /**
     * Returns the context's information of the services handling this request.
     * @return the context's information of the services handling this request, or an empty services
     */
    public ContextInfo getContextInfo() {
        if (contextInfo == null) {
            contextInfo = getVirtualHost().getContextInfoByUriPath(getPath());
        }
        return contextInfo;
    }

    /**
     * Closes this response and flushes all output.
     * @throws IOException if an error occurs
     */
    @Override
    public void close() throws IOException {
        requestMessageInputStream.close();
    }

}
