package com.adobe.assignment.extension.streams;

import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Objects;
import java.util.logging.Logger;

import com.adobe.assignment.extension.messages.header.Headers;
import com.adobe.assignment.extension.utilities.Utils;

/**
 * The {@code ChunkedOutputStream} encodes an OutputStream with the "chunked" transfer encoding. It should be used only
 * when the content length is not known in advance, and with the response Transfer-Encoding header set to "chunked".
 * <p>
 * Data is written to the stream by calling the {@link #write(byte[], int, int)} method, which writes a new chunk per
 * invocation. To end the stream, the {@link #writeTrailingChunk} method must be called or the stream closed.
 */
public class ChunkedOutputStream extends FilterOutputStream {

    private static final Logger LOGGER = Logger.getLogger(ChunkedOutputStream.class.getName());

    private int state;

    /**
     * Constructs a ChunkedOutputStream with the given underlying stream.
     * @param outputStream the underlying output stream to which the chunked stream is written
     * @throws NullPointerException if the given stream is null
     */
    public ChunkedOutputStream(OutputStream outputStream) throws NullPointerException {
        super(outputStream);
        Objects.requireNonNull(outputStream,
                "The underlying output stream to which the chunked stream is written cannot be null!");
    }

    /**
     * Initializes a new chunk with the given size.
     * @param size the chunk size (must be positive)
     * @throws IllegalArgumentException if size is negative
     * @throws IOException if an IO error occurs, or the stream has already been ended
     */
    private void initChunk(long size) throws IOException {
        if (size < 0) {
            LOGGER.warning("invalid size: " + size);
            throw new IllegalArgumentException("invalid size: " + size);
        }
        if (state > 0) {
            out.write(Utils.CRLF);
        } else if (state == 0) {
            state = 1;
        } else {
            LOGGER.warning("chunked stream has already ended");
            throw new IOException("chunked stream has already ended");
        }
        out.write(Utils.getBytes(Long.toHexString(size)));
        out.write(Utils.CRLF);
    }

    /**
     * Writes the trailing chunk which marks the end of the stream.
     * @param headers the (optional) trailing headers to write, or null
     * @throws IOException if an error occurs
     */
    private void writeTrailingChunk(Headers headers) throws IOException {
        initChunk(0);
        if (headers == null) {
            out.write(Utils.CRLF);
        } else {
            headers.writeTo(out);
        }
        state = -1;
    }

    /**
     * Writes a chunk containing the given byte. This method initializes a new chunk of size 1, and then writes the byte
     * as the chunk data.
     * @param data the byte to write as a chunk
     * @throws IOException if an error occurs
     */
    @Override
    public void write(int data) throws IOException {
        write(new byte[] { (byte) data }, 0, 1);
    }

    /**
     * Writes a chunk containing the given bytes. This method initializes a new chunk of the given size, and then writes
     * the chunk data.
     * @param data an array containing the bytes to write
     * @param off the offset within the array where the data starts
     * @param length the length of the data in bytes
     * @throws IOException if an error occurs
     * @throws IndexOutOfBoundsException if the given offset or length are outside the bounds of the given array
     */
    @Override
    public void write(byte[] data, int off, int length) throws IOException {
        if (length > 0) {
            initChunk(length);
        }
        out.write(data, off, length);
    }

    /**
     * Writes the trailing chunk if necessary, and closes the underlying stream.
     * @throws IOException if an error occurs
     */
    @Override
    public void close() throws IOException {
        if (state > -1) {
            writeTrailingChunk(null);
        }
        super.close();
    }
}