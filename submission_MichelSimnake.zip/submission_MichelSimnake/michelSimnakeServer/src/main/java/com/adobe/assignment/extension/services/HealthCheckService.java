package com.adobe.assignment.extension.services;

import java.io.IOException;

import com.adobe.assignment.extension.messages.Request;
import com.adobe.assignment.extension.messages.Response;
import com.adobe.assignment.extension.messages.ResponseStatusCode;

/**
 * The {@code HealthCheckService} provides a service by returning the Health Check
 */
public class HealthCheckService implements IContextHandler {

    @Override
    public ResponseStatusCode respond(Request clientRequest, Response serverResponse) throws IOException {
        serverResponse.getHeaders()
                .add("Content-Type", "application/json");
        serverResponse.writeResponseMessage(ResponseStatusCode.STATUS_OK_200, "{\"healthCheck\" : \"UP\"}", -1);
        return ResponseStatusCode.STATUS_UNKNOWN_STATUS_0;
    }
}
