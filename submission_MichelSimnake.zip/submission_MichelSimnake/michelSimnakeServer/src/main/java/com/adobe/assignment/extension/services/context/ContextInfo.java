package com.adobe.assignment.extension.services.context;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.adobe.assignment.extension.hosts.Domain;
import com.adobe.assignment.extension.services.IContextHandler;

/**
 * The {@code ContextInfo} class holds a single services's information.
 */
public class ContextInfo {

    private final String path;
    private final Map<String, IContextHandler> handlers = new ConcurrentHashMap<>(2);
    private final Domain domain;

    /**
     * Constructs a ContextInfo with the given services path.
     * @param path the services path (without trailing slash)
     * @param domain the virtual host representing one domain and sub-domain of the server
     */
    public ContextInfo(String path, Domain domain) {
        this.path = path;
        this.domain = domain;
    }

    /**
     * Returns the services path.
     * @return the services path, or null if there is none
     */
    public String getPath() {
        return path;
    }

    /**
     * Returns the map of supported HTTP methods and their corresponding handlers.
     * @return the map of supported HTTP methods and their corresponding handlers
     */
    public Map<String, IContextHandler> getHandlers() {
        return handlers;
    }

    /**
     * Returns the corresponding handler of supported HTTP method.
     * @param method the HTTP methods supported by the handler
     * @return handler of supported HTTP method or {@code null} if this map contains no mapping for the key
     */
    public IContextHandler getHandlerByMethod(String method) {
        return handlers.get(method);
    }

    /**
     * Adds (or replaces) a services handler for the given HTTP methods.
     * @param handler the services handler
     * @param methods the HTTP methods supported by the handler (default is "GET")
     */
    public void addHandler(IContextHandler handler, String... methods) {
        if (methods.length == 0) {
            methods = new String[] { "GET" };
        }
        for (String method : methods) {
            handlers.put(method, handler);
            domain.getMethods()
                    .add(method);
        }
    }
}