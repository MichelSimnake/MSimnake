package com.adobe.assignment.extension.messages.header;

import com.adobe.assignment.extension.messages.ResponseStatusCode;

/**
 * The {@code FileHeader} class encapsulates a partial HTTP header for a file content resource. The primary goal of this
 * class is Object Parameter functionalities.
 * @see com.adobe.assignment.extension.services.DirectoryFileContentService
 */
public final class PartialHeader {
    private final long length;
    private final long fileLastModifiedTime;
    private final String computedEntityTag;
    private final ResponseStatusCode responseStatus;
    private final long[] range;

    /**
     * Constructs a PartialHeader with the given file's length, the file last modified time, the computed entity tag,
     * the response status and he range.
     * @param length the length
     * @param fileLastModifiedTime the file last modified time
     * @param computedEntityTag the computed entity tag
     * @param responseStatus the response status
     * @param range the range
     */
    public PartialHeader(long length, long fileLastModifiedTime, String computedEntityTag,
            ResponseStatusCode responseStatus, long[] range) {
        this.length = length;
        this.fileLastModifiedTime = fileLastModifiedTime;
        this.computedEntityTag = computedEntityTag;
        this.responseStatus = responseStatus;
        this.range = range;
    }

    /**
     * Returns the length of the file.
     * @return this header's name
     */
    public long getLength() {
        return length;
    }

    public long getFileLastModifiedTime() {
        return fileLastModifiedTime;
    }

    public String getComputedEntityTag() {
        return computedEntityTag;
    }

    public ResponseStatusCode getResponseStatus() {
        return responseStatus;
    }

    public long[] getRange() {
        return range;
    }
}
