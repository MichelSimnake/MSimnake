package com.adobe.assignment.extension.utilities;

import java.io.File;
import java.util.logging.Logger;

import org.apache.commons.cli.*;

/**
 * The {@code MichelSimnakeServerCommandLine} encapsulates Command Line functionality.
 */
public class MichelSimnakeServerCommandLine {
    private static final Logger LOGGER = Logger.getLogger(MichelSimnakeServerCommandLine.class.getName());
    private File directory;
    private int port;
    private String[] args;
    private Options serverOptions = new Options();

    /**
     * Constructs a MichelSimnakeServer CommandLine from application start parameters provvided by the user.
     * @param args Application's input parameters
     */
    public MichelSimnakeServerCommandLine(String[] args) {

        this.args = args;

        serverOptions.addOption("d", "dir", true,
                "[Required] Location of the Directory whose content will be served by the server.");
        serverOptions.addOption("p", "port", true, "[Optional] The port where the server is listening from.");
        serverOptions.addOption("h", "help", false, "show help.");

    }

    /**
     * Gets directory.
     * @return the directory
     */
    public File getDirectory() {
        return directory;
    }

    /**
     * Gets port.
     * @return the port
     */
    public int getPort() {
        return port;
    }

    /**
     * Parses Application's input parameters
     **/
    public void parse() {
        CommandLineParser parser = new DefaultParser();

        CommandLine cmdLine;
        try {
            cmdLine = parser.parse(serverOptions, args);

            if (cmdLine.hasOption("h")) {
                help();
            }

            if (cmdLine.hasOption("p")) {
                try {
                    LOGGER.info("Using cli argument -p=" + cmdLine.getOptionValue("p"));
                    port = Integer.parseInt(cmdLine.getOptionValue("p"));
                } catch (NumberFormatException numberFormatException) {
                    LOGGER.severe("Failed to parse Port number" + numberFormatException.getMessage());
                    port = 8000;
                }
            } else {
                port = 8000;
            }

            if (cmdLine.hasOption("d")) {
                LOGGER.info("Using cli argument -d=" + cmdLine.getOptionValue("d"));
                directory = new File(cmdLine.getOptionValue("d"));
            } else {
                LOGGER.severe("Missing d option");
                help();
            }

        } catch (ParseException parseException) {
            LOGGER.severe("Failed to parse command line properties" + parseException.getMessage());
            help();
        }
    }

    private void help() {
        HelpFormatter formatter = new HelpFormatter();

        formatter.printHelp("michelSimnake_server.jar", serverOptions);
        System.exit(0);
    }
}