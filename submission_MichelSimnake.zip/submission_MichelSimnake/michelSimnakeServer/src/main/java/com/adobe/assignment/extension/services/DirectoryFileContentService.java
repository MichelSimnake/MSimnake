package com.adobe.assignment.extension.services;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;

import com.adobe.assignment.extension.messages.Request;
import com.adobe.assignment.extension.messages.Response;
import com.adobe.assignment.extension.messages.ResponseStatusCode;
import com.adobe.assignment.extension.messages.header.Headers;
import com.adobe.assignment.extension.messages.header.PartialHeader;
import com.adobe.assignment.extension.utilities.Utils;

/**
 * The {@code DirectoryFileContentService} provides a service by mapping it to a file or folder (recursively) on disk.
 */
public class DirectoryFileContentService implements IContextHandler {

    private final File baseDirectory;
    private final int port;

    /**
     * Constructs a new Directory or File content service who is used to map a file or folder.
     * @param port the port on which this server will accept connections
     * @param directory the existing and readable directory whose contents are served
     * @throws IOException if an error occurs
     */
    public DirectoryFileContentService(int port, File directory) throws IOException {
        baseDirectory = directory.getCanonicalFile();
        this.port = port;
    }

    @Override
    public ResponseStatusCode respond(Request clientRequest, Response serverResponse) throws IOException {
        return serveFile(port, baseDirectory, clientRequest.getContextInfo()
                .getPath(), clientRequest, serverResponse);
    }

    /**
     * Provides a Directory or File's contents from a file based resource.
     * <p>
     * The file is located by stripping the given services prefix from the request's path, and appending the result to
     * the given base directory.
     * <p>
     * Missing, forbidden and otherwise invalid files return the appropriate error response. Directories are served as
     * an HTML index page if the Domain or sub-domain allows one, or a forbidden error otherwise. Files are sent with
     * their corresponding content types, and handle conditional and partial retrievals according to the RFC.
     * @param port the port on which this server will accept connections
     * @param baseDirectory the base directory to which the services is mapped
     * @param context the services which is mapped to the base directory
     * @param clientRequest the request
     * @param serverResponse the response into which the content is written
     * @return the HTTP status code to return, or 0 if a response was sent
     * @throws IOException if an error occurs
     */
    private ResponseStatusCode serveFile(int port, File baseDirectory, String context, Request clientRequest,
            Response serverResponse) throws IOException {
        String relativePath = clientRequest.getPath()
                .substring(context.length());
        File file = new File(baseDirectory, relativePath).getCanonicalFile();
        if (!file.exists()
                || file.isHidden()
                || file.getName()
                        .startsWith(".")) {
            return ResponseStatusCode.STATUS_NOT_FOUND_404;
        } else if (!file.canRead()
                || !file.getPath()
                        .startsWith(baseDirectory.getPath())) {
            return ResponseStatusCode.STATUS_FORBIDDEN_403;
        } else if (file.isDirectory()) {
            if (relativePath.endsWith("/")) {
                if (!clientRequest.getVirtualHost()
                        .isAllowGeneratedIndex()) {
                    return ResponseStatusCode.STATUS_FORBIDDEN_403;
                } else {
                    serveFolderContent(clientRequest, serverResponse, file);
                }
            } else {
                serverResponse.redirect(clientRequest.getBaseURL(port) + clientRequest.getPath() + "/", true);
            }
        } else if (relativePath.endsWith("/")) {
            return ResponseStatusCode.STATUS_NOT_FOUND_404;
        } else {
            serveFileContent(file, clientRequest, serverResponse);
        }
        return ResponseStatusCode.STATUS_UNKNOWN_STATUS_0;
    }

    /**
     * Serve folder content boolean.
     * @param clientRequest the client request
     * @param serverResponse the server response into which the content is written
     * @param file the Folder whose content will be served
     * @throws IOException the io exception
     */
    private void serveFolderContent(Request clientRequest, Response serverResponse, File file) throws IOException {
        String messageBody = Utils.createHtmlDirectoryContent(file, clientRequest.getPath());
        String computedEntityTag = "W/\"" + Integer.toHexString(messageBody.hashCode()) + "\"";
        long directoryLastModifiedTime = file.lastModified();

        ResponseStatusCode responseStatus = IContextHandler.getConditionalStatus(clientRequest,
                directoryLastModifiedTime, computedEntityTag);
        updateResponseHeaders(serverResponse, messageBody, directoryLastModifiedTime, computedEntityTag,
                responseStatus);
    }

    /**
     * Writes additional response headers with regard to the File given a response status code.
     * @param serverResponse the server response
     * @param messageBody the text body (sent as text/html)
     * @param directoryLastModifiedTime the last modified Time of the response resource, or non-positive if unknown. A
     *            time in the future will be replaced with the current system time.
     * @param computedEntityTag HexString message body
     * @param responseStatus the response status
     * @throws IOException the io exception
     */
    private void updateResponseHeaders(Response serverResponse, String messageBody, long directoryLastModifiedTime,
            String computedEntityTag, ResponseStatusCode responseStatus) throws IOException {
        Headers responseHeaders = serverResponse.getHeaders();
        switch (responseStatus) {
        case STATUS_BAD_REQUEST_400:
            serverResponse.writeHeaders(ResponseStatusCode.STATUS_BAD_REQUEST_400);
            break;
        case STATUS_NOT_MODIFIED_304:
            responseHeaders.add("ETag", computedEntityTag);
            responseHeaders.add("Vary", "Accept-Encoding");
            responseHeaders.add("Last-Modified", Utils.formatDate(directoryLastModifiedTime));
            serverResponse.writeHeaders(ResponseStatusCode.STATUS_NOT_MODIFIED_304);
            break;
        case STATUS_PRECONDITION_FAILED_412:
            serverResponse.writeHeaders(ResponseStatusCode.STATUS_PRECONDITION_FAILED_412);
            break;
        case STATUS_OK_200:
            serverResponse.writeResponseMessage(ResponseStatusCode.STATUS_OK_200, messageBody,
                    directoryLastModifiedTime);
            break;
        default:
            serverResponse.writeHeaders(ResponseStatusCode.STATUS_INTERNAL_SERVER_ERROR_500);
            break;
        }
    }

    /**
     * Serves the contents of a file, with its corresponding content type, last modification time, etc. conditional and
     * partial retrievals are handled according to the RFC.
     * @param file the existing and readable file whose contents are served
     * @param clientRequest the client request
     * @param serverResponse the server response into which the content is written
     * @throws IOException if an error occurs
     */
    private void serveFileContent(File file, Request clientRequest, Response serverResponse) throws IOException {
        long length = file.length();
        long fileLastModifiedTime = file.lastModified();
        String computedEntityTag = "W/\"" + fileLastModifiedTime + "\"";
        ResponseStatusCode responseStatus = ResponseStatusCode.STATUS_OK_200;
        long[] range = clientRequest.getRange(length);
        if (range == null || length == 0) {
            responseStatus = IContextHandler.getConditionalStatus(clientRequest, fileLastModifiedTime,
                    computedEntityTag);
        } else {
            String ifRange = clientRequest.getHeaders()
                    .getHeaderValueByName("If-Range");
            if (ifRange == null) {
                if (range[0] >= length) {
                    responseStatus = ResponseStatusCode.STATUS_REQUESTED_RANGE_NOT_SATISFIABLE_416;
                } else {
                    responseStatus = IContextHandler.getConditionalStatus(clientRequest, fileLastModifiedTime,
                            computedEntityTag);
                }
            } else if (range[0] >= length) {
                range = null;
            } else {
                if (!ifRange.startsWith("\"") && !ifRange.startsWith("W/")) {
                    Date date = clientRequest.getHeaders()
                            .getDate("If-Range");
                    if (date != null && fileLastModifiedTime > date.getTime()) {
                        range = null;
                    }
                } else if (!ifRange.equals(computedEntityTag)) {
                    range = null;
                }
            }
        }
        updateResponseHeaders(file, serverResponse, new PartialHeader(length, fileLastModifiedTime, computedEntityTag,
                responseStatus, range));
    }

    /**
     * Writes additional response headers with regard to the File given a response status code.
     * @param file the file
     * @param serverResponse the server response
     * @param partialHeader the partial file header
     * @throws IOException the io exception
     */
    private void updateResponseHeaders(File file, Response serverResponse, PartialHeader partialHeader)
            throws IOException {
        Headers responseHeaders = serverResponse.getHeaders();
        switch (partialHeader.getResponseStatus()) {
        case STATUS_BAD_REQUEST_400:
            serverResponse.writeHeaders(ResponseStatusCode.STATUS_BAD_REQUEST_400);
            break;
        case STATUS_NOT_MODIFIED_304:
            responseHeaders.add("ETag", partialHeader.getComputedEntityTag());
            responseHeaders.add("Vary", "Accept-Encoding");
            responseHeaders.add("Last-Modified", Utils.formatDate(partialHeader.getFileLastModifiedTime()));
            serverResponse.writeHeaders(ResponseStatusCode.STATUS_NOT_MODIFIED_304);
            break;
        case STATUS_PRECONDITION_FAILED_412:
            serverResponse.writeHeaders(ResponseStatusCode.STATUS_PRECONDITION_FAILED_412);
            break;
        case STATUS_REQUESTED_RANGE_NOT_SATISFIABLE_416:
            responseHeaders.add("Content-Range", "bytes */" + partialHeader.getLength());
            serverResponse.writeHeaders(ResponseStatusCode.STATUS_REQUESTED_RANGE_NOT_SATISFIABLE_416);
            break;
        case STATUS_OK_200:
            serverResponse.writeHeaders(ResponseStatusCode.STATUS_OK_200, partialHeader.getLength(), partialHeader
                    .getFileLastModifiedTime(), partialHeader.getComputedEntityTag(), Utils.getContentType(file
                            .getName(), "application/octet-stream"), partialHeader.getRange());

            try (InputStream in = new FileInputStream(file)) {
                serverResponse.writeMessageBody(in, partialHeader.getLength(), partialHeader.getRange());
            }
            break;
        default:
            serverResponse.writeHeaders(ResponseStatusCode.STATUS_INTERNAL_SERVER_ERROR_500);
            break;
        }
    }
}