package com.adobe.assignment.extension.streams;

import java.io.IOException;
import java.io.InputStream;
import java.util.logging.Logger;

import com.adobe.assignment.extension.messages.header.Headers;
import com.adobe.assignment.extension.utilities.Utils;

/**
 * The {@code ChunkedInputStream} decodes an InputStream whose data has the "chunked" transfer encoding applied to it,
 * providing the underlying data.
 */
public class ChunkedInputStream extends LimitedInputStream {

    private static final Logger LOGGER = Logger.getLogger(ChunkedInputStream.class.getName());

    private Headers headers;
    private boolean initialized;

    /**
     * Constructs a ChunkedInputStream with the given underlying stream, and a headers container to which the stream's
     * trailing headers will be added.
     * @param inputStream the underlying "chunked"-encoded input stream
     * @param headers the headers container to which the stream's trailing headers will be added, or null if they are to
     *            be discarded
     * @throws NullPointerException if the given stream is null
     */
    public ChunkedInputStream(InputStream inputStream, Headers headers) {
        super(inputStream, 0, true);
        this.headers = headers;
    }

    /**
     * Parses a chunk-size line.
     * @param line the chunk-size line to parse
     * @return the chunk size
     * @throws IllegalArgumentException if the chunk-size line is invalid
     */
    private static long parseChunkSize(String line) throws IllegalArgumentException {
        int pos = line.indexOf(';');
        line = pos < 0 ? line : line.substring(0, pos);
        try {
            return Utils.parseULong(line, 16);
        } catch (NumberFormatException numberFormatException) {
            LOGGER.warning("invalid chunk size line: \"" + line + "\"");
            throw new IllegalArgumentException("invalid chunk size line: \"" + line + "\"");
        }
    }

    @Override
    public int read() throws IOException {
        return limit <= 0 && initializeNextChunk() < 0 ? -1 : super.read();
    }

    @Override
    public int read(byte[] data, int off, int length) throws IOException {
        return limit <= 0 && initializeNextChunk() < 0 ? -1 : super.read(data, off, length);
    }

    /**
     * Initializes the next chunk. If the previous chunk has not yet ended, or the end of stream has been reached, does
     * nothing.
     * @return the length of the chunk, or -1 if the end of stream has been reached
     * @throws IOException if an IO error occurs or the stream is corrupt
     */
    private long initializeNextChunk() throws IOException {
        if (limit == 0) {
            if (initialized
                    && Utils.readLine(in)
                            .length() > 0) {
                LOGGER.warning("chunk data must end with CRLF");
                throw new IOException("chunk data must end with CRLF");
            }
            initialized = true;
            limit = parseChunkSize(Utils.readLine(in));
            if (limit == 0) {
                limit = -1;
                Headers trailingHeaders = Utils.readHeaders(in);
                if (headers != null) {
                    headers.addAll(trailingHeaders);
                }
            }
        }
        return limit;
    }
}