package com.adobe.assignment.extension.processors;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import com.adobe.assignment.extension.MichelSimnakeServer;
import com.adobe.assignment.extension.messages.Request;
import com.adobe.assignment.extension.messages.Response;

/**
 * The {@code IHttpProcessor} interface provides the Http processor contracts.
 */
public interface IHttpProcessor {

    /**
     * Returns the http server.
     * @return the http server
     */
    MichelSimnakeServer getHttpServer();

    /**
     * processes communications for a single connection over the given streams. Multiple subsequent transactions are
     * handled on the connection, until the streams are closed, an error occurs, or the request contains a "Connection:
     * close" header which explicitly requests the connection be closed after the transaction ends.
     * @param requestInputStream the stream from which the incoming requests are read
     * @param out the stream into which the outgoing responses are written
     * @throws IOException if an error occurs
     */
    void processHttpRequest(InputStream requestInputStream, OutputStream out) throws IOException;

    /**
     * processes a single transaction on a connection.
     * <p>
     * Subclasses can override this method to perform filtering on the request or response, apply wrappers to them, or
     * further customize the transaction processing in some other way.
     * @param clientRequest the transaction request
     * @param serverResponse the transaction response (into which the response is written)
     * @throws IOException if and error occurs
     */
    void processTransaction(Request clientRequest, Response serverResponse) throws IOException;

    /**
     * Preprocesses a transaction, performing various validation checks and required special header handling, possibly
     * returning an appropriate response.
     * @param clientRequest the request
     * @param serverResponse the response
     * @return whether further processing should be performed on the transaction
     * @throws IOException if an error occurs
     */
    boolean preprocessTransaction(Request clientRequest, Response serverResponse) throws IOException;

    /**
     * processes a transaction according to the request method.
     * @param clientRequest the transaction request
     * @param serverResponse the transaction response (into which the response is written)
     * @throws IOException if and error occurs
     */
    void processHttpRequest(Request clientRequest, Response serverResponse) throws IOException;

    /**
     * Serves the content for a request by invoking the services handler for the requested services (path) and HTTP
     * method.
     * @param clientRequest the request
     * @param serverResponse the response into which the content is written
     * @throws IOException if an error occurs
     */
    void deliverContent(Request clientRequest, Response serverResponse) throws IOException;

}
