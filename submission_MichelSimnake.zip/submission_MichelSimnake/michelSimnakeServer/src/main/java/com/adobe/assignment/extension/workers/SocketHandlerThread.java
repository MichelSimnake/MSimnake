package com.adobe.assignment.extension.workers;

import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Logger;

import javax.net.ssl.SSLSocket;

import com.adobe.assignment.extension.processors.IHttpProcessor;
import com.adobe.assignment.extension.utilities.Utils;

/**
 * The {@code SocketHandlerThread} handles accepted sockets.
 */
public class SocketHandlerThread extends Thread {

    private static final Logger LOGGER = Logger.getLogger(SocketHandlerThread.class.getName());

    private IHttpProcessor httpProcessor;

    /**
     * Allocates a new {@code Thread} object.
     * @param name the name of the new thread
     * @param httpProcessor the http processor
     */
    public SocketHandlerThread(String name, IHttpProcessor httpProcessor) {
        super(name);
        this.httpProcessor = httpProcessor;
    }

    @Override
    public void run() {
        setName(getClass().getSimpleName()
                + "-"
                + httpProcessor.getHttpServer()
                        .getPort());
        try (ServerSocket listener = httpProcessor.getHttpServer()
                .getListener()) {
            while (listener != null && !listener.isClosed()) {
                Socket clientSocket = listener.accept();
                httpProcessor.getHttpServer()
                        .getServiceExecutor()
                        .execute(() -> {
                            LOGGER.info("Worker thread is processing its http client's request.");
                            try {
                                try {
                                    clientSocket.setSoTimeout(Utils.SOCKET_TIMEOUT);
                                    clientSocket.setTcpNoDelay(true);
                                    InputStream requestInputStream = clientSocket.getInputStream();
                                    httpProcessor.processHttpRequest(requestInputStream, clientSocket
                                            .getOutputStream());
                                    LOGGER.info("The Worker Thread has sent a Http Response to the client.");
                                } finally {
                                    try {
                                        if (!(clientSocket instanceof SSLSocket)) {
                                            clientSocket.shutdownOutput();
                                            Utils.transfer(clientSocket.getInputStream(), null, -1);
                                        }
                                    } finally {
                                        clientSocket.close();
                                        LOGGER.info("The Worker Thread has closed the client's socket.");
                                    }
                                }
                            } catch (IOException iOException) {
                                LOGGER.severe("Processing the http client's request has failed. "
                                        + iOException.getMessage());
                            }
                        });
            }
        } catch (IOException iOException) {
            LOGGER.severe("Processing the http client's request has failed. " + iOException.getMessage());
        }
    }
}