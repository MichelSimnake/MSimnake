package com.adobe.assignment.extension.streams;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;
import java.util.logging.Logger;

/**
 * The {@code LimitedInputStream} provides access to a limited number of consecutive bytes from the underlying
 * InputStream, starting at its current position. If this limit is reached, it behaves as though the end of stream has
 * been reached (although the underlying stream remains open and may contain additional data).
 */
public class LimitedInputStream extends FilterInputStream {

    private static final Logger LOGGER = Logger.getLogger(LimitedInputStream.class.getName());

    long limit;
    private boolean prematureEndException;

    /**
     * Constructs a LimitedInputStream with the given underlying input stream and limit.
     * @param inputStream the underlying input stream
     * @param limit the maximum number of bytes that may be consumed from the underlying stream before this stream ends.
     *            If zero or negative, this stream will be at its end from initialization.
     * @param prematureEndException specifies the stream's behavior when the underlying stream end is reached before the
     *            limit is reached: if true, an exception is thrown, otherwise this stream reaches its end as well (i.e.
     *            read() returns -1)
     * @throws NullPointerException if the given stream is null
     */
    public LimitedInputStream(InputStream inputStream, long limit, boolean prematureEndException) {
        super(inputStream);
        Objects.requireNonNull(inputStream, "The underlying input stream cannot be null!");
        this.limit = limit < 0 ? 0 : limit;
        this.prematureEndException = prematureEndException;
    }

    @Override
    public int read() throws IOException {
        int res = limit == 0 ? -1 : in.read();
        if (res < 0 && limit > 0 && prematureEndException) {
            LOGGER.warning("unexpected end of stream");
            throw new IOException("unexpected end of stream");
        }
        limit = res < 0 ? 0 : limit - 1;
        return res;
    }

    @Override
    public int read(byte[] data, int off, int length) throws IOException {
        int res = limit == 0 ? -1 : in.read(data, off, length > limit ? (int) limit : length);
        if (res < 0 && limit > 0 && prematureEndException) {
            LOGGER.warning("unexpected end of stream");
            throw new IOException("unexpected end of stream");
        }
        limit = res < 0 ? 0 : limit - res;
        return res;
    }

    @Override
    public long skip(long length) throws IOException {
        long res = in.skip(Math.min(length, limit));
        limit -= res;
        return res;
    }

    @Override
    public int available() throws IOException {
        int res = in.available();
        return res > limit ? (int) limit : res;
    }

    @Override
    public boolean markSupported() {
        return false;
    }

    @Override
    public void close() {
        limit = 0;
    }
}
