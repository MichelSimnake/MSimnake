package com.adobe.assignment.extension.hosts;

import java.util.Collections;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.logging.Logger;

import com.adobe.assignment.extension.services.IContextHandler;
import com.adobe.assignment.extension.services.context.ContextInfo;
import com.adobe.assignment.extension.utilities.Utils;

/**
 * The {@code Domain} class represents a virtual host (domain or sub-domain in the server).
 */
public class Domain {

    private static final Logger LOGGER = Logger.getLogger(Domain.class.getName());

    private final String name;
    private final Set<String> aliases = new CopyOnWriteArraySet<>();
    private final Set<String> methods = new CopyOnWriteArraySet<>();
    private final ContextInfo emptyContextInfo = new ContextInfo(null, this);
    private final ConcurrentMap<String, ContextInfo> contextInfos = new ConcurrentHashMap<>();
    private volatile boolean allowGeneratedIndex;

    /**
     * Constructs a Domain with the given name.
     * @param name the host's name, or null if it is the default host
     */
    public Domain(String name) {
        this.name = name;
        contextInfos.put("*", new ContextInfo(null, this));
    }

    /**
     * Returns this host's name.
     * @return this host's name, or null if it is the default host
     */
    public String getName() {
        return name;
    }

    /**
     * Returns this host's aliases.
     * @return the (unmodifiable) set of aliases (which may be empty)
     */
    public Set<String> getAliases() {
        return Collections.unmodifiableSet(aliases);
    }

    /**
     * Returns this host's directory index file name.
     * @return the html index file name, or null
     */
    public String getHtmlIndexFileName() {
        return "index.html";
    }

    /**
     * Returns whether auto-generated indices are allowed.
     * @return whether auto-generated indices are allowed
     */
    public boolean isAllowGeneratedIndex() {
        return allowGeneratedIndex;
    }

    /**
     * Sets whether auto-generated indices are allowed. If false, and a directory resource is requested, an error will
     * be returned instead.
     * @param allowed specifies whether generated indices are allowed
     */
    public void setAllowGeneratedIndex(boolean allowed) {
        allowGeneratedIndex = allowed;
    }

    /**
     * Returns all HTTP methods explicitly supported by at least one services (this may or may not include the methods
     * with required or built-in support).
     * @return all HTTP methods explicitly supported by at least one services
     */
    public Set<String> getMethods() {
        return methods;
    }

    /**
     * Returns the services Info for the given path.
     * <p>
     * If a services is not found for the given path, the search is repeated for its parent path, and so on until a base
     * services is found. If neither the given path nor any of its parents has a services, an empty services is
     * returned.
     * @param path the services's path
     * @return the services info for the given path, or an empty services if none exists
     */
    public ContextInfo getContextInfoByUriPath(String path) {
        for (path = Utils.trimRightCharacters(path, "/"); path != null; path = Utils.getParentPath(path)) {
            ContextInfo contextInfo = contextInfos.get(path);
            if (contextInfo != null) {
                return contextInfo;
            }
        }
        return emptyContextInfo;
    }

    /**
     * Adds a services info and its corresponding services handler to this server. Paths are normalized by removing
     * trailing slashes (except the root).
     * @param path the services's path (must start with '/')
     * @param handler the services handler for the given path
     * @param methods the HTTP methods supported by the services handler (default is "GET")
     * @throws IllegalArgumentException if path is malformed
     */
    public void addContextInfo(String path, IContextHandler handler, String... methods) {
        if (path == null || !path.startsWith("/") && !path.equals("*")) {
            LOGGER.warning("headers were already sent ");
            throw new IllegalArgumentException("invalid path: " + path);
        }
        path = Utils.trimRightCharacters(path, "/");
        ContextInfo contextInfo = new ContextInfo(path, this);
        ContextInfo currentContextInfo = contextInfos.putIfAbsent(path, contextInfo);
        contextInfo = currentContextInfo != null ? currentContextInfo : contextInfo;
        contextInfo.addHandler(handler, methods);
    }
}
