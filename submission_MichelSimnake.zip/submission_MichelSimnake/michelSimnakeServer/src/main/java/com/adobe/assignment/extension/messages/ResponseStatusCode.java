package com.adobe.assignment.extension.messages;

import java.util.Arrays;

/**
 * The {@code ResponseStatusCode} class encapsulates a Http response status.
 */
public enum ResponseStatusCode {

    STATUS_UNKNOWN_STATUS_0(0, "Unknown Status"),
    STATUS_CONTINUE_100(100, "Continue"),
    STATUS_OK_200(200, "OK"),
    STATUS_NO_CONTENT_204(204, "No Content"),
    STATUS_PARTIAL_CONTENT_206(206, "Partial Content"),
    STATUS_MOVED_PERMANENTLY_301(301, "Moved Permanently"),
    STATUS_FOUND_302(302, "Found"),
    STATUS_NOT_MODIFIED_304(304, "Not Modified"),
    STATUS_TEMPORARY_REDIRECT_307(307, "Temporary Redirect"),
    STATUS_BAD_REQUEST_400(400, "Bad Request"),
    STATUS_UNAUTHORIZED_401(401, "Unauthorized"),
    STATUS_FORBIDDEN_403(403, "Forbidden"),
    STATUS_NOT_FOUND_404(404, "Not Found"),
    STATUS_METHOD_NOT_ALLOWED_405(405, "Method Not Allowed"),
    STATUS_REQUEST_TIMEOUT_408(408, "Request Timeout"),
    STATUS_PRECONDITION_FAILED_412(412, "Precondition Failed"),
    STATUS_REQUEST_ENTITY_TOO_LARGE_413(413, "Request Entity Too Large"),
    STATUS_REQUEST_URI_TOO_LARGE_414(414, "Request-URI Too Large"),
    STATUS_REQUESTED_RANGE_NOT_SATISFIABLE_416(416, "Requested Range Not Satisfiable"),
    STATUS_EXPECTATION_FAILED_417(417, "Expectation Failed"),
    STATUS_INTERNAL_SERVER_ERROR_500(500, "Internal Server Error"),
    STATUS_NOT_IMPLEMENTED_501(501, "Not Implemented"),
    STATUS_BAD_GATEWAY_502(502, "Bad Gateway"),
    STATUS_SERVICE_UNAVAILABLE_503(503, "Service Unavailable"),
    STATUS_GATEWAY_TIME_OUT_504(504, "Gateway Time-out"),
    STATUS_UNKNOWN_STATUS_520(520, "Unknown Status");

    private int statusCode;
    private String statusDescription;

    ResponseStatusCode(int code, String description) {
        statusCode = code;
        statusDescription = description;
    }

    /**
     * Returns http response status for a giving status code.
     * @param code the code
     * @return the response status by code
     * @throws IllegalArgumentException if the status code is not found
     */
    public static ResponseStatusCode getResponseStatusByCode(int code) {
        return Arrays.stream(ResponseStatusCode.values())
                .filter(s -> s.statusCode == code)
                .findAny()
                .orElseThrow(() -> new IllegalArgumentException(code + ": Unsupported Status code value"));
    }

    /**
     * Returns the http response status code.
     * @return the status code of the http response
     */
    public int getStatusCode() {
        return statusCode;
    }

    /**
     * Returns the http response status code's description.
     * @return the status code description of the http response
     */
    public String getStatusDescription() {
        return statusDescription;
    }
}
