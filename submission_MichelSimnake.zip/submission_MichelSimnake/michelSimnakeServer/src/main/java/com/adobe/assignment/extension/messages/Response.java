package com.adobe.assignment.extension.messages;

import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.GZIPOutputStream;

import org.apache.commons.lang3.ArrayUtils;

import com.adobe.assignment.extension.messages.header.Headers;
import com.adobe.assignment.extension.streams.ChunkedOutputStream;
import com.adobe.assignment.extension.utilities.Utils;

/**
 * The {@code Response} class encapsulates a single HTTP response.
 */
public class Response implements Closeable {

    private static final Logger LOGGER = Logger.getLogger(Response.class.getName());

    private OutputStream requestOutputStream;
    private OutputStream[] encoders = new OutputStream[4];
    private Headers headers;
    private boolean discardBody;
    private int state;
    private Request request;

    /**
     * Constructs a Response whose output is written to the given stream.
     * @param requestOutputStream the stream to which the response is written
     */
    public Response(OutputStream requestOutputStream) {
        this.requestOutputStream = requestOutputStream;
        headers = new Headers();
    }

    /**
     * Sets whether this response's body is discarded or sent.
     * @param discardBody specifies whether the body is discarded or not
     */
    public void setDiscardBody(boolean discardBody) {
        this.discardBody = discardBody;
    }

    /**
     * Sets the request which is used in determining the capabilities supported by the client (e.g. compression,
     * encoding, etc.)
     * @param request the request
     */
    public void setClientCapabilities(Request request) {
        this.request = request;
    }

    /**
     * Returns the request headers collection.
     * @return the request headers collection
     */
    public Headers getHeaders() {
        return headers;
    }

    /**
     * Returns the underlying output stream to which the response is written. Except for special cases, you should use
     * {@link #getBodyOutputStream()} instead.
     * @return the underlying output stream to which the response is written
     */
    public OutputStream getOutputStream() {
        return requestOutputStream;
    }

    /**
     * Returns whether the response headers were already written.
     * @return whether the response headers were already written
     */
    public boolean isHeadersAlreadyWritten() {
        return state == 1;
    }

    /**
     * Returns an output stream into which the response body can be written. The stream applies encodings (e.g.
     * compression) according to the sent headers. This method must be called after response headers have been sent that
     * indicate there is a body. Normally, the content should be prepared (not sent) even before the headers are sent,
     * so that any errors during processing can be caught and a proper error response returned - after the headers are
     * sent, it's too late to change the status into an error.
     * @return an output stream into which the response body can be written, or null if the body should not be written
     *         (e.g. it is discarded)
     * @throws IOException if an error occurs
     */
    private OutputStream getBodyOutputStream() throws IOException {
        if (encoders[0] != null || discardBody) {
            return encoders[0];
        }
        List<String> responseTransferEncoding = Utils.splitElementsToList(headers.getHeaderValueByName(
                "Transfer-Encoding"), true);
        List<String> responseContentEncoding = Utils.splitElementsToList(headers.getHeaderValueByName(
                "Content-Encoding"), true);
        int i = encoders.length - 1;
        encoders[i] = new FilterOutputStream(requestOutputStream) {
            @Override
            public void close() {
            }

            @Override
            public void write(byte[] b, int off, int len) throws IOException {
                out.write(b, off, len);
            }
        };
        if (responseTransferEncoding.contains("chunked")) {
            encoders[--i] = new ChunkedOutputStream(encoders[i + 1]);
        }
        if (responseContentEncoding.contains("gzip") || responseTransferEncoding.contains("gzip")) {
            encoders[--i] = new GZIPOutputStream(encoders[i + 1], 4096);
        } else if (responseContentEncoding.contains("deflate") || responseTransferEncoding.contains("deflate")) {
            encoders[--i] = new DeflaterOutputStream(encoders[i + 1]);
        }
        encoders[0] = encoders[i];
        encoders[i] = null;
        return encoders[0];
    }

    /**
     * Closes this response and flushes all output.
     * @throws IOException if an error occurs
     */
    @Override
    public void close() throws IOException {
        state = -1;
        if (encoders[0] != null) {
            encoders[0].close();
        }
        requestOutputStream.flush();
    }

    /**
     * Writes the response headers with the given response status. A Date header is added if it does not already exist.
     * If the response has a body, the Content-Length/Transfer-Encoding and Content-Type headers must be set before
     * sending the headers.
     * @param responseStatusCode the response status
     * @throws IOException if an error occurs or headers were already sent
     * @see #writeHeaders(ResponseStatusCode, long, long, String, String, long[])
     */
    public void writeHeaders(ResponseStatusCode responseStatusCode) throws IOException {
        if (isHeadersAlreadyWritten()) {
            LOGGER.warning("headers were already sent ");
            throw new IOException("headers were already sent");
        }
        if (!headers.contains("Date")) {
            headers.add("Date", Utils.formatDate(System.currentTimeMillis()));
        }

        if (!headers.contains("Set-Cookie")) {
            Date date = Utils.addOneDay(new Date(System.currentTimeMillis()));
            String domain = (request == null) ? null : request.getPath();
            headers.createCookies("Set-Cookie", "def", "123", date, 2, domain);
        }
        requestOutputStream.write(Utils.getBytes("HTTP/1.1 ", Integer.toString(responseStatusCode.getStatusCode()), " ",
                responseStatusCode.getStatusDescription()));
        requestOutputStream.write(Utils.CRLF);
        headers.writeTo(requestOutputStream);
        state = 1;
    }

    /**
     * Writes the response headers, including the given response status and description, and all response headers. If
     * they do not already exist, the following headers are added as necessary: Content-Range, Content-Type,
     * Transfer-Encoding, Content-Encoding, Content-Length, Last-Modified, ETag, Connection and Date. Ranges are
     * properly calculated as well, with a 200 status changed to a 206 status.
     * @param responseStatusCode the response status
     * @param length the response body length, or zero if there is no body, or negative if there is a body but its
     *            length is not yet known
     * @param lastModified the last modified date of the response resource, or non-positive if unknown. A time in the
     *            future will be replaced with the current system time.
     * @param entityTag the ETag of the response resource, or null if unknown (see RFC2616#3.11)
     * @param contentType the content type of the response resource, or null if unknown (in which case
     *            "application/octet-stream" will be sent)
     * @param range the content range that will be sent, or null if the entire resource will be sent
     * @throws IOException if an error occurs
     */
    public void writeHeaders(ResponseStatusCode responseStatusCode, long length, long lastModified, String entityTag,
            String contentType, long[] range) throws IOException {
        if (range != null) {
            headers.add("Content-Range", "bytes " + range[0] + "-" + range[1] + "/" + (length >= 0 ? length : "*"));
            length = range[1] - range[0] + 1;
            if (responseStatusCode.getStatusCode() == 200) {
                responseStatusCode = ResponseStatusCode.STATUS_PARTIAL_CONTENT_206;
            }
        }
        String responseContentType = headers.getHeaderValueByName("Content-Type");
        if (responseContentType == null) {
            responseContentType = contentType != null ? contentType : "application/octet-stream";
            headers.add("Content-Type", responseContentType);
        }
        if (!headers.contains("Content-Length") && !headers.contains("Transfer-Encoding")) {
            boolean modern = request != null
                    && request.getVersion()
                            .endsWith("1.1");
            String accepted = request == null ? null : request.getHeaders()
                    .getHeaderValueByName("Accept-Encoding");

            String[] elements = Utils.splitElements(accepted, true);
            if (ArrayUtils.isNotEmpty(elements)) {
                List<String> encodings = Arrays.asList(elements);
                String compression = encodings.contains("gzip") ? "gzip" : encodings.contains("deflate") ? "deflate"
                        : null;
                if (compression != null
                        && (length < 0 || length > 300)
                        && Utils.isCompressible(responseContentType)
                        && modern) {
                    headers.add("Transfer-Encoding", "chunked");
                    headers.add("Content-Encoding", compression);
                } else if (length < 0 && modern) {
                    headers.add("Transfer-Encoding", "chunked");
                } else if (length >= 0) {
                    headers.add("Content-Length", Long.toString(length));
                }
            }
        }

        if (!headers.contains("Vary")) {
            headers.add("Vary", "Accept-Encoding");
        }
        if (lastModified > 0 && !headers.contains("Last-Modified")) {
            headers.add("Last-Modified", Utils.formatDate(Math.min(lastModified, System.currentTimeMillis())));
        }
        if (entityTag != null && !headers.contains("ETag")) {
            headers.add("ETag", entityTag);
        }
        if (request != null
                && "close".equalsIgnoreCase(request.getHeaders()
                        .getHeaderValueByName("Connection"))
                && !headers.contains("Connection")) {
            headers.add("Connection", "close");
        }
        writeHeaders(responseStatusCode);
    }

    /**
     * Writes the full response with the given status, and the given string as the body. The text is written in the
     * UTF-8 charset. If a Content-Type header was not explicitly set, it will be set to text/html, and so the text must
     * contain valid (and properly {@link Utils#escapeHTML escaped}) HTML.
     * @param responseStatusCode the response status
     * @param messageBody the text body (sent as text/html)
     * @param lastModifiedTime the last modified Time of the response resource, or non-positive if unknown. A time in
     *            the future will be replaced with the current system time.
     * @throws IOException if an error occurs
     */
    public void writeResponseMessage(ResponseStatusCode responseStatusCode, String messageBody, long lastModifiedTime)
            throws IOException {
        byte[] messageBodyContent = messageBody.getBytes(StandardCharsets.UTF_8);
        writeHeaders(responseStatusCode, messageBodyContent.length, lastModifiedTime, "W/\""
                + Integer.toHexString(messageBody.hashCode())
                + "\"", "text/html; charset=utf-8", null);
        OutputStream responseBodyOutputStream = getBodyOutputStream();
        if (responseBodyOutputStream != null) {
            responseBodyOutputStream.write(messageBodyContent);
        }
    }

    /**
     * Writes an error response with the given status and detailed messages. An HTML body is created containing the
     * status and its description, as well as the messages, which is escaped using the {@link Utils#escapeHTML escape}
     * method.
     * @param responseStatusCode the response status
     * @param text the text body (written as text/html)
     * @throws IOException if an error occurs
     */
    public void writeError(ResponseStatusCode responseStatusCode, String text) throws IOException {
        String messageBody = String.format("<!DOCTYPE html>%n"
                + "<html>%n"
                + "<head>"
                + "<title>%d %s</title>"
                + "</head>%n"
                + "<body><h1>%d %s</h1>%n"
                + "<p>%s</p>%n"
                + "</body></html>", responseStatusCode.getStatusCode(), responseStatusCode.getStatusCode(),
                responseStatusCode.getStatusCode(), responseStatusCode.getStatusDescription(), Utils.escapeHTML(text));
        writeResponseMessage(responseStatusCode, messageBody, -1);
    }

    /**
     * Writes an error response with the given status and default body.
     * @param responseStatusCode the response status
     * @throws IOException if an error occurs
     */
    public void writeError(ResponseStatusCode responseStatusCode) throws IOException {
        String text = responseStatusCode.getStatusCode() < 400 ? responseStatusCode.getStatusDescription()
                : "Bad Request: Unfortunately the requested resource cannot be served.";
        writeError(responseStatusCode, text);
    }

    /**
     * Writes the response body. This method must be called only after the response headers have been written (and
     * indicate that there is a messages body).
     * @param body a stream containing the response messages body
     * @param length the full length of the response messages body
     * @param range the sub-range within the response body that should be written, or null if the entire body should be
     *            written
     * @throws IOException if an error occurs
     */
    public void writeMessageBody(InputStream body, long length, long[] range) throws IOException {
        OutputStream bodyOutputStream = getBodyOutputStream();
        if (bodyOutputStream != null) {
            if (range != null) {
                long offset = range[0];
                length = range[1] - range[0] + 1;
                while (offset > 0) {
                    long skip = body.skip(offset);
                    if (skip == 0) {
                        LOGGER.warning("can't skip to " + range[0]);
                        throw new IOException("can't skip to " + range[0]);
                    }
                    offset -= skip;
                }
            }
            Utils.transfer(body, bodyOutputStream, length);
        }
    }

    /**
     * Writes a 301 or 302 response, redirecting the client to the given URL.
     * @param url the absolute URL to which the client is redirected
     * @param permanent specifies whether a permanent (301) or temporary (302) redirect status is written
     * @throws IOException if an IO error occurs or url is malformed
     */
    public void redirect(String url, boolean permanent) throws IOException {
        try {
            url = new URI(url).toASCIIString();
        } catch (URISyntaxException uRISyntaxExceptione) {
            LOGGER.severe("malformed URL: " + url);
            throw new IOException("malformed URL: " + url);
        }
        headers.add("Location", url);
        if (permanent) {
            writeError(ResponseStatusCode.STATUS_MOVED_PERMANENTLY_301, "Permanently moved to " + url);
        } else {
            writeError(ResponseStatusCode.STATUS_FOUND_302, "Temporarily moved to " + url);
        }
    }
}