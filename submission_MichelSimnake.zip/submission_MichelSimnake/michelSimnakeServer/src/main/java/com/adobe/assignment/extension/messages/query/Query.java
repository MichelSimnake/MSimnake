package com.adobe.assignment.extension.messages.query;

import java.util.logging.Logger;

/**
 * The {@code Query} class encapsulates a single HTTP request query parameter.
 */
public class Query {

    private static final Logger LOGGER = Logger.getLogger(Query.class.getName());

    private final String name;
    private final String value;

    private final QueryType queryType;

    /**
     * Constructs a query with the given name and value. Leading and trailing whitespace are trimmed.
     * @param name the query name
     * @param value the query value
     * @param queryType the query type
     * @throws NullPointerException if name or value is null
     * @throws IllegalArgumentException if name is empty
     */
    public Query(String name, String value, QueryType queryType) throws NullPointerException, IllegalArgumentException {
        this.name = name.trim();
        this.value = value.trim();
        this.queryType = queryType;
        if (this.name.length() == 0) {
            LOGGER.warning("name cannot be empty");
            throw new IllegalArgumentException("name cannot be empty");
        }
    }

    /**
     * Returns this query's name.
     * @return this query's name
     */
    public String getName() {
        return name;
    }

    /**
     * Returns this query's value.
     * @return this query's value
     */
    public String getValue() {
        return value;
    }

    /**
     * Returns this query's type.
     * @return this query's type
     */
    public QueryType getQueryType() {
        return queryType;
    }

    public enum QueryType {
        BODY,
        URI
    }
}
